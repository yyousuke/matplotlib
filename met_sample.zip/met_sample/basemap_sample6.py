#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap

# プロット領域の作成
fig = plt.figure()

# Basemap呼び出し
m = Basemap()

# 海岸線を描く
m.drawcoastlines()

# 国境線を描く
m.drawcountries()

# 河川を描く
m.drawrivers(color='b')

# 経度線を引く
m.drawmeridians(np.arange(0, 360, 30), color="k", fontsize='small',
                labels=[False, False, False, True])

# 緯度線を引く
m.drawparallels(np.arange(-90, 90, 30), color="k", fontsize='small',
                labels=[True, False, False, False])

# ファイルへの書き出し
fig_fname = "Fig6-1-7.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
