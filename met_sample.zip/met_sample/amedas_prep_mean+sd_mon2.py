#!/usr/bin/env python3
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import math
import numpy as np
from amesta import AmedasStation

# 平均と標準偏差を計算する期間（複数）
syears = [1960]
eyears = [2021]

# 地点名
sta = "Tokyo"
#
# 月のリスト
months = [
    "jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct",
    "nov", "dec"
]

title = "Mean & SD of Precipitation"


def get_data(syear, eyear, prep_i):
    # データの取り出し
    # 降水量(mm)
    prepm = list()
    prepsd = list()
    max_y = list()
    xlabel = list()
    for n in np.arange(len(months)):
        # 月間降水量
        prep = prep_i.loc[syear:eyear, months[n]]
        # 平均、標準偏差の計算
        prepm.append(prep.mean())
        prepsd.append(prep.std())
        # y軸上の最大値
        max_y.append(math.ceil(prep.mean() + prep.std()))
        # x軸の目盛り
        xlabel.append(str(months[n]).capitalize())
    print("mean = ", prepm, "period = ", syear, "-", eyear)
    print("SD = ", prepsd, "period = ", syear, "-", eyear)
    return (prepm, prepsd, max_y, xlabel)


def main():
    #
    # AmedasStation Classの初期化
    amedas = AmedasStation(sta)
    # AmedasStation.retrieve_monメソッドを使い、降水量データを取得
    prep_i = amedas.retrieve_mon("prep")
    #
    # x軸のindex
    index = np.arange(len(months)) + 1.0
    #

    # 作図
    # プロットエリアの定義
    #fig, ax1 = plt.subplots()
    fig = plt.figure(figsize=(6, 3))
    ax = fig.add_subplot(1, 1, 1)
    #
    # タイトルを付ける
    plt.title(title + ',' + sta)
    #
    # データの取得
    prepm, prepsd, max_y, xlabel = get_data(syears[0], eyears[0], prep_i)
    #
    # 作図範囲の設定
    plt.xlim([0.5, len(months) + 0.5])
    plt.ylim([0, np.max(max_y) + 50])
    #
    # 棒グラフ
    error_config = {'ecolor': '0.3', 'capsize': 6}
    plt.bar(index, prepm, yerr=prepsd, error_kw=error_config, 
            color='b', width=0.4, alpha=0.4, label='Mean Precipitation')
    #
    # y軸のラベル
    plt.ylabel('Precipitation (mm)')
    # y軸の目盛り
    ax.yaxis.set_major_locator(ticker.AutoLocator())
    ax.yaxis.set_minor_locator(ticker.AutoMinorLocator())
    # x軸の目盛り
    ax.set_xticks(np.arange(len(months)) + 1)
    ax.set_xticklabels(xlabel)
    #
    # 凡例
    plt.legend(loc='best')
    #
    # グリッド線を描く
    plt.grid(color='gray', ls=':')
    # プロット範囲の調整
    plt.subplots_adjust(hspace=0.8, bottom=0.2)
    #
    # ファイルへの書き出し
    fig_fname = "Fig4-2-5.png"
    plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
    #
    plt.show()


#
main()
