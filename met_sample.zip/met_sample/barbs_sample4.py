#!/usr/bin/env python3
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

#
# プロットエリアの定義
fig = plt.figure(figsize=(6, 1.5))
ax = fig.add_subplot(1, 1, 1)
ax.set_xlim([0.85, 2.15])
ax.set_ylim([1.0, 2.0])

x = (1.0, 1.25, 1.5, 1.75, 2.0)
y = (1.5, 1.5, 1.5, 1.5, 1.5)
u = (45.0, 70.0, 0.0, -35.0, -50.0)
v = (70.0, 45.0, -15.0, 25.0, 0.0)

# 矢羽を描く
plt.barbs(x, y, u, v, barbcolor=['b', 'g'], flagcolor='r')

# x軸の目盛り
ax.xaxis.set_major_locator(ticker.NullLocator())
ax.xaxis.set_minor_locator(ticker.NullLocator())
# y軸の目盛り
ax.yaxis.set_major_locator(ticker.NullLocator())
ax.yaxis.set_minor_locator(ticker.NullLocator())

# ファイルへの書き出し
fig_fname = "Fig5-1-7.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
