#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap

# プロット領域の作成
fig = plt.figure()

# Basemap呼び出し
# 極座標表示（nps相当）の準備（low resolutionの海岸線）
m = Basemap(projection='npstere', lon_0=180, boundinglat=20, resolution='l')

# 海岸線を描く
m.drawcoastlines(linewidth=0.2, color='k')

# 背景に色を付ける
#m.drawmapboundary(fill_color='aqua')

# 大陸に色を付ける
#m.fillcontinents(color='w', lake_color='b')

# 経度線を引く
m.drawmeridians(np.arange(0, 360, 30), color="0.9", fontsize='small',
                labels=[False, False, False, True])

# 緯度線を引く
m.drawparallels(np.arange(-90, 90, 30), color="0.9", fontsize='small',
                labels=[True, False, False, False])

# データの読み込み
idim = 144
jdim = 73
num_rec = 860
datasize = idim * jdim
din = np.fromfile("output.bin", dtype='<f4', count=datasize * num_rec)
slp = np.zeros((num_rec, jdim, idim + 1))
slp[:, :, 0:idim] = din.reshape(num_rec, jdim, idim)
slp[:, :, idim] = slp[:, :, 0]
idim = idim + 1
#
# 1981〜2010年の７月平均値
tstr = (1981 - 1948) * 12 + 6
tend = (2010 - 1948 + 1) * 12
slp_jul = slp[tstr:tend:12, :, :].mean(axis=0)
#
# 経度・緯度座標の準備（単位は度）
nlats = jdim
nlons = idim
delta = 360. / (nlons - 1)
lats = (90. - delta * np.indices((nlats, nlons))[0, :, :])
lons = (delta * np.indices((nlats, nlons))[1, :, :])
# 図法の経度、緯度に変換する
x, y = m(lons, lats)
#
# 等値線を描く
clevs = np.arange(np.floor(slp_jul.min() - np.fmod(slp_jul.min(), 20)),
                  np.ceil(slp_jul.max()) + 1, 4)
cs = m.contour(x, y, slp_jul, clevs, linewidths=0.8, colors='k')

# ラベルを付ける
clevels = cs.levels
cs.clabel(clevels[::5], fontsize=12, fmt="%d")

# 2018年７月の偏差
n = (2018 - 1948) * 12 + 6
slp_anom = slp[n, :, :] - slp_jul
# 陰影を描く
work = max(np.abs(np.floor(slp_anom.min())), np.abs(np.ceil(slp_anom.max())))
clevs = np.arange(-(work + 1), work + 1)
# 色テーブルの設定
cmap = plt.get_cmap('bwr')  # 色テーブル取得
m.contourf(x, y, slp_anom, clevs, cmap=cmap)

# カラーバーを付ける
cbar = plt.colorbar(orientation='vertical', pad=0.03, format="%5.1f")
#cbar=plt.colorbar(shrink=0.55, orientation='vertical', pad=0.03, format="%5.1f")
cbar.set_label('SLP anom. in Jul. 2018', fontsize=12)

# ファイルへの書き出し
fig_fname = "Fig6-6-2.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
