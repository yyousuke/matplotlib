#!/usr/bin/env python3
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np

title = "Histogram"

# サンプルサイズを設定
size_of_sample = 1000
# ビンの端点の設定
edges = np.arange(0, 100, 5)
# 作図範囲の設定
xmin = 0
xmax = 100
ymin = 0
ymax = 0.1

# 平均、標準偏差の指定
mu1, sigma1 = 50, 10
mu2, sigma2 = 30, 4

# 作図オプションのリスト
STYLES = [
    dict(color='b', alpha=0.4, edgecolor='k', label='$\mu=50,\ \sigma=10$'),
    dict(color='r', alpha=0.4, edgecolor='k', label='$\mu=30,\ \sigma=4$')
]

# 再現性を保つため、random stateを固定
np.random.seed(1900)
# ランダムデータの準備
hist_y1 = mu1 + sigma1 * np.random.randn(size_of_sample)
hist_y2 = mu2 + sigma2 * np.random.randn(size_of_sample)

# プロットエリアの定義
#fig, ax1 = plt.subplots()
fig = plt.figure(figsize=(6, 6))
ax = fig.add_subplot(1, 1, 1)

# タイトルを付ける
plt.title(title)

# ヒストグラム
plt.hist(hist_y1, density=True, bins=edges, **STYLES[0])
plt.hist(hist_y2, density=True, bins=edges, **STYLES[1])

# x軸、y軸の範囲
plt.xlim([xmin, xmax])
plt.ylim([ymin, ymax])

# x軸、y軸のラベル
plt.xlabel('x')
plt.ylabel('Frequency')

# 凡例を描く
plt.legend(loc='best')

# グリッド線を描く
plt.grid(color='gray', ls=':')
# プロット範囲の調整
plt.subplots_adjust(hspace=0.8, bottom=0.2)
#
# ファイルへの書き出し
fig_fname = "Fig4-4-7.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
#
plt.show()
