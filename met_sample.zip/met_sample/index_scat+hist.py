#!/usr/bin/env python3
from pandas import Series, DataFrame
import pandas as pd
import numpy as np
import urllib.request
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from matplotlib import gridspec
plt.rcParams['xtick.direction'] = 'in'  # x軸目盛線を内側
plt.rcParams['xtick.major.width'] = 1.2  # x軸大目盛線の長さ
plt.rcParams['ytick.direction'] = 'in'  # y軸目盛線を内側
plt.rcParams['ytick.major.width'] = 1.2  # y軸大目盛線の長さ

# plot range
#syear = 1950
syear = 2010
eyear = 2019
retrieve = False

# 軸の範囲の設定(散布図、ヒストグラム共通)
xmin = -5
xmax = 5
ymin = -5
ymax = 5

# ビンの端点の設定（ヒストグラム）
edges = np.arange(-5, 5, 0.5)

# 軸のラベルとタイトルの設定
xlabel = 'AO'
ylabel = 'NAO'
title = "Scatter diagram"


# n:標本の大きさ、r: 相関係数、Zxx:a/2に対するパーセント点
def r_range(n, r, Zxx):
    Z = 0.5 * np.log((1 + r) / (1 - r))
    ZU = Z + Zxx / np.sqrt(n - 3)
    ZL = Z - Zxx / np.sqrt(n - 3)
    # 信頼限界
    ru = (np.exp(2 * ZU) - 1) / (np.exp(2 * ZU) + 1)
    rl = (np.exp(2 * ZL) - 1) / (np.exp(2 * ZL) + 1)
    return (ru, rl)


# AOI
url = "http://www.cpc.ncep.noaa.gov/products/precip/CWlink/daily_ao_index/monthly.ao.index.b50.current.ascii"
if retrieve:
    urllib.request.urlretrieve(url, "ao.txt")

# NAOI
url = "http://www.cpc.ncep.noaa.gov/products/precip/CWlink/pna/norm.nao.monthly.b5001.current.ascii"
if retrieve:
    urllib.request.urlretrieve(url, "nao.txt")

# ファイルから読み込み
dataset1 = pd.read_fwf("ao.txt", header=None, parse_dates=[[0, 1]],
                       index_col=[0], names=["year", "mon", "aoi"])
dataset2 = pd.read_fwf("nao.txt", header=None, parse_dates=[[0, 1]],
                       index_col=[0], names=["year", "mon", "naoi"])
#
# 入力データの作成
data_x = dataset1.loc[str(syear) + "-01-01":str(eyear) + "-12-31", "aoi"]
data_y = dataset2.loc[str(syear) + "-01-01":str(eyear) + "-12-31", "naoi"]

# プロットエリアの定義
fig = plt.figure(figsize=(6, 6))
# GridSpecを使いサブプロット生成
gs = gridspec.GridSpec(2, 2, width_ratios=(6, 1), height_ratios=(4, 1))
ax = [plt.subplot(gs[0, 0]), plt.subplot(gs[0, 1]), plt.subplot(gs[1, 0])]

# メインの散布図
ax[0].scatter(data_x, data_y, color='r', marker='o', s=24, 
              edgecolor='k', label='original', zorder=3)  # 散布図

ax[0].axvline(x=0, color='k', ls=':', zorder=1)  # x=0の線を付ける
ax[0].axhline(y=0, color='k', ls=':', zorder=1)  # y=0の線を付ける
ax[0].grid(color='gray', ls=':')  # グリッド線を描く

#ax[0].legend(loc='best') # 凡例

# タイトルを付ける
ax[0].set_title(title, fontsize=20)
# x軸のラベル
#ax[0].set_xlabel(xlabel, fontsize=16)
# y軸のラベル
ax[0].set_ylabel(ylabel, fontsize=16)
#
# x軸の目盛り
ax[0].xaxis.set_major_locator(ticker.AutoLocator())
ax[0].xaxis.set_minor_locator(ticker.AutoMinorLocator())
# y軸の目盛り
ax[0].yaxis.set_major_locator(ticker.AutoLocator())
ax[0].yaxis.set_minor_locator(ticker.AutoMinorLocator())
# 作図範囲の設定
ax[0].set_xlim([xmin, xmax])
ax[0].set_ylim([ymin, ymax])

# 相関係数の出力
corr = np.corrcoef(data_x, data_y)
#
# 相関係数に対して95%の信頼区間を計算
ru, rl = r_range(len(data_x), corr[1, 0], 1.96)
name = "{s1:s}{f1:4.3f}{s2:s}{f2:4.3f}{s3:s}{f3:4.3f}{s4:s}".format(s1="r = ", \
f1=corr[1,0], s2=" (", f2=rl, s3="-", f3=ru, s4=")")
print("corr = ", corr[1, 0], "ru, rl = ", ru, rl)
xloc = xmin + 0.05 * (xmax - xmin)  # x軸上の座標
yloc = ymax - 0.05 * (ymax - ymin)  # y軸上の座標
# 相関係数を表示
ax[0].text(xloc, yloc, name, fontsize=14, color='k')

# 回帰式の係数
a = corr[1, 0] * data_y.std() / data_x.std()
b = data_y.mean() - a * data_x.mean()
name = "{s1:s}{f1:4.3f}{s2:s}{f2:4.3f}".format(s1="y = ", f1=a, s2="x + ", f2=b)
xloc = xmin + 0.05 * (xmax - xmin)  # x軸上の座標
yloc = ymax - 0.10 * (ymax - ymin)  # y軸上の座標
print(name)
# 回帰式の計算
x1 = np.linspace(np.floor(xmin), np.ceil(xmax), len(data_x))
y1 = a * x1 + b
# 回帰式のプロット
ax[0].plot(x1, y1, color='k', lw=3, label='linear fit', zorder=2)
# 回帰式を表示
ax[0].text(xloc, yloc, name, fontsize=14, color='k')

# 凡例を付ける
ax[0].legend(loc='lower right')
#plt.legend(loc='best')

# 右側のヒストグラム
ax[1].hist(data_y, density=True, bins=edges, orientation="horizontal", 
           color='b', alpha=0.4, edgecolor='k')
#ax[1].invert_xaxis()       # 左右反転
ax[1].yaxis.tick_right()  # 縦軸の目盛りを右側に配置
# x軸の範囲（軸が変わったのでy軸を変更）
ax[1].set_ylim([ymin, ymax])
# y軸の範囲（軸が変わったのでx軸を変更）
ax[1].set_xlim([0, 0.6])
# x軸の目盛り
ax[1].xaxis.set_major_locator(ticker.AutoLocator())
ax[1].xaxis.set_minor_locator(ticker.AutoMinorLocator())
# y軸の目盛り
ax[1].yaxis.set_major_locator(ticker.AutoLocator())
ax[1].yaxis.set_minor_locator(ticker.AutoMinorLocator())

# 下のヒストグラム
ax[2].hist(data_x, density=True, bins=edges, 
           color='b', alpha=0.4, edgecolor='k')
#ax[2].tick_params(labelbottom="on") # 軸の目盛線ラベルを有効
#ax[2].tick_params(labelbottom="off")
# x軸の範囲
ax[2].set_xlim([xmin, xmax])
# y軸の範囲
ax[2].set_ylim([0, 0.6])
# x軸のラベル
ax[2].set_xlabel(xlabel, fontsize=16)
# x軸の目盛り
ax[2].xaxis.set_major_locator(ticker.AutoLocator())
ax[2].xaxis.set_minor_locator(ticker.AutoMinorLocator())
# y軸の目盛り
ax[2].yaxis.set_major_locator(ticker.AutoLocator())
ax[2].yaxis.set_minor_locator(ticker.AutoMinorLocator())

# プロット範囲の調整
plt.subplots_adjust(top=None, bottom=0.1, wspace=0.10, hspace=0.10)
#plt.subplots_adjust(top=None, bottom=0.1, wspace=0.25, hspace=0.20)
#plt.subplots_adjust(hspace=0.8,bottom=0.2)

# ファイルへの書き出し
fig_fname = "Fig4-6-2.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
