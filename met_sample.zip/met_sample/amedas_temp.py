#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from amesta import AmedasStation

# 地点名
sta = "Tokyo"
# 月（3文字）
month = "jul"

#
# AmedasStation Classの初期化
amedas = AmedasStation(sta)
#
# AmedasStation.retrieve_monメソッドを使い、平均気温データを取得
tave_i = amedas.retrieve_mon("tave")
#
# データの取り出し
tave = tave_i.loc[:, month]

# 作図
# プロットエリアの定義
fig = plt.figure(figsize=(6, 3))
ax = fig.add_subplot(1, 1, 1)
#
# タイトルを付ける
title = "Yearly timeseries of July, Tokyo"
plt.title(title)
#
#
# 気温（C）
plt.ylim([20, 30])
plt.plot(tave, color='r', ls='-', label='Ave. Temp.')
plt.ylabel('Temperature ($^{\circ}$C)')
#
# y軸の目盛り
ax.yaxis.set_major_locator(ticker.AutoLocator())
ax.yaxis.set_minor_locator(ticker.AutoMinorLocator())
# x軸の目盛り
ax.xaxis.set_major_locator(ticker.AutoLocator())
ax.xaxis.set_minor_locator(ticker.AutoMinorLocator())
# 凡例を付ける
plt.legend(loc='best')
#
# グリッド線を描く
plt.grid(color='gray', ls=':')
# プロット範囲の調整
plt.subplots_adjust(hspace=0.8, bottom=0.2)
#
# ファイルへの書き出し
fig_fname = "Fig4-1-1.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
#
# 画面へ表示
plt.show()
