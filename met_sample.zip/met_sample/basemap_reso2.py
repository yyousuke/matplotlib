#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap

# プロット領域の作成
fig = plt.figure(figsize=(6, 9))

for n in np.arange(6):
    ax = fig.add_subplot(3, 2, n + 1)
    # Basemap呼び出し( ランベルト図法)
    if n == 0:
        # resolution='c'
        m = Basemap(projection='lcc', lat_0=35, lon_0=135,
                    width=6e5, height=6e5, resolution='c')
        ax.set_title(" resolution='c'")
    elif n == 1:
        # resolution='l'
        m = Basemap(projection='lcc', lat_0=35, lon_0=135,
                    width=6e5, height=6e5, resolution='l')
        ax.set_title(" resolution='l'")
    elif n == 2:
        # resolution='i'
        m = Basemap(projection='lcc', lat_0=35, lon_0=135,
                    width=6e5, height=6e5, resolution='i')
        ax.set_title(" resolution='i'")
    elif n == 3:
        # resolution='h'
        m = Basemap(projection='lcc', lat_0=35, lon_0=135,
                    width=6e5, height=6e5, resolution='h')
        ax.set_title(" resolution='h'")
    elif n == 4:
        # resolution='f'
        m = Basemap(projection='lcc', lat_0=35, lon_0=135,
                    width=6e5, height=6e5, resolution='f')
        ax.set_title(" resolution='f'")
    elif n == 5:
        # default
        m = Basemap(projection='lcc', lat_0=35, lon_0=135,
                    width=6e5, height=6e5)
        ax.set_title("default")

    # 海岸線を描く
    m.drawcoastlines(color='k', linewidth=0.5)
    #
    # 背景に色を付ける
    #m.drawmapboundary(fill_color='aqua')
    #
    # 大陸に色を付ける
    #m.fillcontinents(color='w')
    #
    # 河川を描く
    m.drawrivers(color='b')

    # 緯度線を引く
    m.drawparallels(np.arange(-90, 90, 1), color="gray", fontsize='xx-small',
                    labels=[True, False, False, False])
    #
    # 経度線を引く
    m.drawmeridians(np.arange(0, 360, 1), color="gray", fontsize='xx-small',
                    labels=[False, False, False, True])
    #m.bluemarble(scale=0.5)

# プロット範囲の調整
plt.subplots_adjust(top=0.8, bottom=0.2, left=0.2, right=0.8,
                    wspace=0.1, hspace=0.25)

# ファイルへの書き出し
fig_fname = "Fig6-3-4.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
