#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap

# プロット領域の作成
fig = plt.figure()

# Basemap呼び出し
# 極座標表示（nps相当）の準備（low resolutionの海岸線）
m = Basemap(projection='npstere', lon_0=180, boundinglat=20, resolution='l')

# 海岸線を描く
m.drawcoastlines(linewidth=0.2, color='k')

# 背景に色を付ける
#m.drawmapboundary(fill_color='aqua')

# 大陸に色を付ける
#m.fillcontinents(color='w', lake_color='b')

# 経度線を引く
m.drawmeridians(np.arange(0, 360, 30), color="0.9", fontsize='small',
                labels=[False, False, False, True])

# 緯度線を引く
m.drawparallels(np.arange(-90, 90, 30), color="0.9", fontsize='small',
                labels=[True, False, False, False])

# データの読み込み
idim = 144
jdim = 73
num_rec = 860
datasize = idim * jdim
# 東西風
uwnd = np.fromfile("output_uwnd.bin", dtype='<f4', count=datasize * num_rec)
u = np.zeros((num_rec, jdim, idim + 1))
u[:, :, 0:idim] = uwnd.reshape(num_rec, jdim, idim)
u[:, :, idim] = u[:, :, 0]
u[:, 0:20, ::2] = 0.0
u[:, 0:10, ::5] = 0.0
# 南北風
vwnd = np.fromfile("output_vwnd.bin", dtype='<f4', count=datasize * num_rec)
v = np.zeros((num_rec, jdim, idim + 1))
v[:, :, 0:idim] = vwnd.reshape(num_rec, jdim, idim)
v[:, :, idim] = v[:, :, 0]
v[:, 0:20, ::2] = 0.0
v[:, 0:10, ::5] = 0.0
idim = idim + 1
#
#
# 経度・緯度座標の準備（単位は度）
nlats = jdim
nlons = idim
delta = 360. / (nlons - 1)
lats = (90. - delta * np.indices((nlats, nlons))[0, :, :])
lons = (delta * np.indices((nlats, nlons))[1, :, :])
# 図法の経度、緯度に変換する
x, y = m(lons, lats)
#
# 2018年７月の東西風、南北風
n = (2018 - 1948) * 12 + 6
# 矢羽を描く
#m.barbs(x, y, u, v, color='k', sizes=dict(emptybarb=0.0), length=6)
m.barbs(x[::3, ::3], y[::3, ::3], u[n, ::3, ::3], v[n, ::3, ::3],
        color='k', sizes=dict(emptybarb=0.0), length=6)

# ファイルへの書き出し
fig_fname = "Fig6-6-4.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
