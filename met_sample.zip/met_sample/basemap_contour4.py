#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap

# プロット領域の作成
fig = plt.figure()

# Basemap呼び出し
# 正距円筒図法（latlon相当）の準備（low resolutionの海岸線）
m = Basemap(projection='cyl', llcrnrlat=-90, urcrnrlat=90, llcrnrlon=0,
            urcrnrlon=360, resolution='l')

# 海岸線を描く
m.drawcoastlines(linewidth=0.2, color='k')

# 背景に色を付ける
#m.drawmapboundary(fill_color='aqua')

# 大陸に色を付ける
#m.fillcontinents(color='w', lake_color='b')

# 経度線を引く
m.drawmeridians(np.arange(0, 360, 30), color="0.9", fontsize='small',
                labels=[False, False, False, True])

# 緯度線を引く
m.drawparallels(np.arange(-90, 90, 30), color="0.9", fontsize='small',
                labels=[True, False, False, False])

# データの読み込み
idim = 144
jdim = 73
rec = 7
datasize = idim * jdim
din = np.fromfile("output.bin", dtype='<f4', count=datasize * rec)
slp = din.reshape(rec, jdim, idim)
print(slp.shape)
#print(slp.min(), slp.max())
#
# 経度・緯度座標の準備
nlats = jdim
nlons = idim
delta = 360. / (nlons - 1)
lats = (90. - delta * np.indices((nlats, nlons))[0, :, :])
lons = (delta * np.indices((nlats, nlons))[1, :, :])
# 図法の経度、緯度に変換する
x, y = m(lons, lats)
#
# 等高線を描く
#clevs = [980, 990, 1000, 1010, 1020]
clevs = np.arange(980, 1040, 4)
cs = m.contour(x, y, slp[rec - 1, :, :], clevs, linewidths=0.8, colors='k')
#cs = m.contour(x, y, slp, levels=clevs, linewidths=0.8, colors='k')

# ラベルを付ける
clevels = cs.levels
#cs.clabel(clevels, fontsize=12, fmt="%d")
cs.clabel(clevels[::5], fontsize=12, fmt="%d")

# ファイルへの書き出し
fig_fname = "Fig6-5-4.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
