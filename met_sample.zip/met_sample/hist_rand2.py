#!/usr/bin/env python3
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np

# 作図オプションのリスト
STYLES = [
    dict(color='gray', alpha=0.4),
    dict(color='b', alpha=0.4),
    dict(color='b', alpha=0.4, edgecolor='k'),
    dict(color='r', alpha=1.0, edgecolor='k')
]

# 再現性を保つため、random stateを固定
np.random.seed(1900)
# ランダムデータの準備
hist_y = np.random.randn(1000)

# プロットエリアの定義
#fig, ax1 = plt.subplots()
fig = plt.figure(figsize=(6, 6))

ax = list()
for n in np.arange(4):
    # サブプロット作成
    ax.append(fig.add_subplot(2, 2, n + 1))
    # ヒストグラム
    ax[n].hist(hist_y, bins='auto', **STYLES[n])
    # グリッド線を描く
    ax[n].grid(color='gray', ls=':')
    # x軸、y軸の範囲
    plt.xlim([-4.5, 4.5])
    plt.ylim([0, 120])

# プロット範囲の調整
plt.subplots_adjust(top=None, bottom=0.1, wspace=0.2, hspace=0.15)
#
# ファイルへの書き出し
fig_fname = "Fig4-4-2.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
#
plt.show()
