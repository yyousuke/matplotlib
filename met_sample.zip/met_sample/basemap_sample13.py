#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap

# プロット領域の作成
fig = plt.figure(figsize=(7, 6))

for n in np.arange(6):
    ax = fig.add_subplot(3, 2, n + 1)
    # Basemap呼び出し
    m = Basemap()

    # 海岸線を描く
    m.drawcoastlines(linewidth=0.2)

    # 背景を衛星画像風にする
    if n == 0:
        m.etopo(scale=0.5)
        ax.set_title("scale=0.5")
    elif n == 1:
        m.etopo(scale=0.2)
        ax.set_title("scale=0.2")
    elif n == 2:
        m.etopo(scale=0.1)
        ax.set_title("scale=0.1")
    elif n == 3:
        m.etopo(scale=0.05)
        ax.set_title("scale=0.05")
    elif n == 4:
        m.etopo(scale=0.01)
        ax.set_title("scale=0.01")
    elif n == 5:
        m.etopo(scale=0.005)
        ax.set_title("scale=0.005")

    # 経度線を引く
    m.drawmeridians(np.arange(0, 360, 30), color="0.9")
    # 緯度線を引く
    m.drawparallels(np.arange(-90, 90, 30), color="0.9")

# ファイルへの書き出し
fig_fname = "Fig6-1-14.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
