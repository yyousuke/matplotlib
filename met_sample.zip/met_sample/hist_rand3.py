#!/usr/bin/env python3
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np

# サンプルサイズを設定
size_of_sample = 1000

# ビン数の設定
num_bins = 20
# 作図範囲の設定
xmin = -4.5
xmax = 4.5
ymin = 0
ymax = 200

# 作図オプションのリスト
STYLES = [
    dict(alpha=0.4, fill=False, hatch='//'),
    dict(color='b', alpha=0.4, fill=True, hatch='++'),
    dict(alpha=0.4, edgecolor='k', fill=False, hatch='xx'),
    dict(alpha=1.0, edgecolor='k', fill=False, hatch='oo')
]

# プロットエリアの定義
fig = plt.figure(figsize=(6, 6))

hist_y = list()
ax = list()
for n in np.arange(4):
    # ランダムデータの準備
    hist_y.append(np.random.randn(size_of_sample))
    # サブプロット作成
    ax.append(fig.add_subplot(2, 2, n + 1))
    # ヒストグラム
    ax[n].hist(hist_y[n], bins=num_bins, **STYLES[n])
    # グリッド線を描く
    ax[n].grid(color='gray', ls=':')
    # x軸の目盛り
    ax[n].xaxis.set_major_locator(ticker.AutoLocator())
    ax[n].xaxis.set_minor_locator(ticker.AutoMinorLocator())
    # x軸、y軸の範囲
    plt.xlim([xmin, xmax])
    plt.ylim([ymin, ymax])

# プロット範囲の調整
plt.subplots_adjust(top=None, bottom=0.1, wspace=0.2, hspace=0.15)
#
# ファイルへの書き出し
fig_fname = "Fig4-4-3.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
#
plt.show()
