#!/usr/bin/env python3
from pandas import DataFrame
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
plt.rcParams['xtick.direction'] = 'in'  # x軸目盛線を内側
plt.rcParams['xtick.major.width'] = 1.2  # x軸主目盛線の長さ
plt.rcParams['ytick.direction'] = 'in'  # y軸目盛線を内側
plt.rcParams['ytick.major.width'] = 1.2  # y軸主目盛線の長さ

# 時刻範囲
stime = "2018-09-04 00:00:00"
etime = "2018-09-05 00:00:00"
# x軸のラベル
xlab = "9/4"

# 入力ファイル名
input_file = "20180903-20180905KIX.csv"
dat_i = pd.read_csv(input_file, parse_dates=[0], index_col=[0])

# 風向の置き換え
list_org = ["静穏", "北北東", "東北東", "東南東", "南南東", "南南西", "西南西", \
"西北西", "北北西", "北東", "南東",  "南西",  "北西",  "北",  "東",   "南",    "西"]
list_new = ["NaN",  "22.5",   "67.5",   "112.5",  "157.5",  "202.5",  "247.5", \
"292.5",  "337.5",  "45.0", "135.0", "225.0", "315.0", "0.0", "90.0", "180.0", "270.0"]
for i in range(len(list_org)):
    dat_i.iloc[:, 2] = dat_i.iloc[:, 2].str.replace(list_org[i], list_new[i])

# データ型の変換
dat = DataFrame(dat_i.copy(), dtype="float64")

# データの取り出し
length = len(dat.loc[stime:etime, :])
ws = dat.loc[stime:etime, "ws"].copy()
wd = dat.loc[stime:etime, "wd"].copy()

# 東西風速、南北風速に変換
u = np.array(ws * np.cos((270.0 - wd) / 180.0 * np.pi))
v = np.array(ws * np.sin((270.0 - wd) / 180.0 * np.pi))

# プロットエリアの定義
fig = plt.figure(figsize=(9, 1))
ax = fig.add_subplot(1, 1, 1)

# 作図範囲の設定
ax.set_xlim([-1, length])
ax.set_ylim([0, 10])

# 矢羽(m/s)
x = np.arange(length)
y = np.ones(length) * 5
ax.barbs(x, y, u, v, color='k', length=4.5, sizes=dict(emptybarb=0.001))

# x軸のラベル
ax.set_xlabel(xlab, fontsize=14)

# x軸の目盛り線
ax.xaxis.set_major_locator(ticker.MultipleLocator(3))
ax.xaxis.set_minor_locator(ticker.MultipleLocator(1))
#ax.xaxis.set_major_locator(ticker.AutoLocator())
#ax.xaxis.set_minor_locator(ticker.AutoMinorLocator())
# y軸の目盛り線
ax.yaxis.set_major_locator(ticker.NullLocator())
ax.yaxis.set_minor_locator(ticker.NullLocator())

# プロット範囲の調整
plt.subplots_adjust(bottom=0.4)
#plt.subplots_adjust(hspace=0.8,bottom=0.4)
#
# ファイルへの書き出し
fig_fname = "Fig5-1-20.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
#
plt.show()
