#
#  2018/07/19 Yamashita
#

from amesta import amedas



__all__ = [
   "AmedasStation"
]

AmedasStation = amedas.AmedasStation

