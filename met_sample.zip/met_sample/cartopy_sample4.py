#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import cartopy.crs as ccrs
import warnings
warnings.filterwarnings('ignore')

# プロット領域の作成
fig = plt.figure()
# cartopy呼び出し
ax = fig.add_subplot(1, 1, 1, projection=ccrs.PlateCarree(central_longitude=180))

# 海岸線を描く
ax.coastlines()

# 経度、緯度線を描く
gl = ax.gridlines(crs=ccrs.PlateCarree(),
                  linewidth=0.5, linestyle='--', color='r', alpha=0.8)
gl.xlocator = mticker.FixedLocator(np.arange(-180, 180, 30))  # 経度線
gl.ylocator = mticker.FixedLocator(np.arange(-90, 90, 30))  # 緯度線

# ファイルへの書き出し
fig_fname = "Fig7-1-4.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
