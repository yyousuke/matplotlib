#!/usr/bin/env python3
import matplotlib.pyplot as plt
from matplotlib import gridspec

#
# プロットエリアの定義
fig = plt.figure(figsize=(8, 7))
# GridSpecを使いサブプロット生成
gs = gridspec.GridSpec(3, 3, height_ratios=(2, 2, 1), width_ratios=(3, 3, 1))
ax = [plt.subplot(gs[:2, :2]), \
      plt.subplot(gs[2, 0]), \
      plt.subplot(gs[:, 2]) ]
ax2 = plt.axes([0.4, 0.35, 0.3, 0.2])

# テキストの表示
ax[0].text(0.5, 0.5, "gs[:2, :2]", ha='center', va='center')
ax[1].text(0.5, 0.5, "gs[2, 0]", ha='center', va='center')
ax[2].text(0.5, 0.5, "gs[:, 2]", ha='center', va='center')
ax2.text(0.5, 0.5, "axes([0.4, 0.35, 0.3, 0.2])", ha='center', va='center')

# ファイルへの書き出し
fig_fname = "Fig4-6-5.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
