#!/usr/bin/env python3
import netCDF4
import numpy as np
import subprocess
import urllib.request
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap
from matplotlib.colors import LinearSegmentedColormap

# 図のタイトル
title = "2020/12/31 18UTC"

# データ取得の有無
retrieve = True
#retrieve = False

# URL
url = "http://database.rish.kyoto-u.ac.jp/arch/jmadata/data/gpv/original/2020/12/31/Z__C_RJTD_20201231180000_GSM_GPV_Rgl_FD0000_grib2.bin"
file_name = "Z__C_RJTD_20201231180000_GSM_GPV_Rgl_FD0000_grib2.bin"
file_name_nc = "20201231180000_GSM_FD0000.nc"
#
# ファイルのダウンロードと変換
if retrieve:
    urllib.request.urlretrieve(url, file_name)
    res = subprocess.run(["wgrib2", file_name, "-netcdf", file_name_nc],
                         stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE)
    print(res.stdout.decode("utf-8"))

#
# NetCDFデータの読み込み
nc = netCDF4.Dataset(file_name_nc, 'r')
# データサイズの取得
idim = len(nc.dimensions['longitude'])
jdim = len(nc.dimensions['latitude'])
# 変数の読み込み
lon = nc.variables["longitude"][:]
lat = nc.variables["latitude"][:]
rh700 = nc.variables["RH_700mb"][:].reshape(jdim, idim)
rh600 = nc.variables["RH_600mb"][:].reshape(jdim, idim)
rh500 = nc.variables["RH_500mb"][:].reshape(jdim, idim)
rh400 = nc.variables["RH_400mb"][:].reshape(jdim, idim)
rh300 = nc.variables["RH_300mb"][:].reshape(jdim, idim)
rh = (rh700 + rh600 + rh500 + rh400 + rh300) / 5.
# ファイルを閉じる
nc.close()

# プロット領域の作成
fig, ax = plt.subplots(figsize=(6, 6))
# タイトルをつける
ax.set_title(title, fontsize=20)

# Basemap呼び出し
# 正射投影図法の準備
m = Basemap(projection='ortho', lon_0=135, lat_0=0)

# 海岸線を描く
m.drawcoastlines(linewidth=0.5, color='g')

# 経度線を引く
m.drawmeridians(np.arange(0, 360, 10), color="0.9",
                fontsize='small', linewidth=0.3)

# 緯度線を引く
m.drawparallels(np.arange(-90, 90, 10), color="0.9",
                fontsize='small', linewidth=0.3)

# 経度・緯度座標の準備
lons, lats = np.meshgrid(lon, lat)
# 図法の経度、緯度に変換する（NetCDFデータの緯度・経度の単位は度）
x, y = m(lons, lats)
#
# 色テーブルの設定
segment_data = {
    'red': [
        (0.0,   0 / 255,   0 / 255),
        (0.5, 128 / 255, 128 / 255),
        (1.0, 255 / 255,   0 / 255),
    ],
    'green': [
        (0.0,   0 / 255,   0 / 255),
        (0.5, 128 / 255, 128 / 255),
        (1.0, 255 / 255,   0 / 255),
    ],
    'blue': [
        (0.0,   0 / 255,   0 / 255),
        (0.5, 128 / 255, 128 / 255),
        (1.0, 255 / 255,   0 / 255),
    ],
}
cmap = LinearSegmentedColormap('colormap_name', segment_data)

# 陰影を描く
cs = m.contourf(x, y, rh, cmap=cmap, extend='both')

# カラーバーを付ける
cbar = m.colorbar(cs, location='right', pad=0.25, format="%3.0f")
#cbar.set_label('RH (%)', fontsize=12)

# ファイルへの書き出し
fig_fname = "Fig6-6-5.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
