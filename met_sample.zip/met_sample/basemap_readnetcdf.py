#!/usr/bin/env python3
import urllib.request
import netCDF4

# データ取得の有無
retrieve = True
#retrieve = False

# URL
url = "http://database.rish.kyoto-u.ac.jp/arch/ncep/data/ncep.reanalysis.derived/surface/slp.mon.mean.nc"
file_name = "slp.mon.mean.nc"
#
# ファイルのダウンロード
if retrieve:
    urllib.request.urlretrieve(url, file_name)

# NetCDFデータの読み込み
nc = netCDF4.Dataset(file_name, 'r')
print(nc)

# ファイルを閉じる
nc.close()
