#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from pandas import Series, DataFrame
import numpy as np
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import math
from amesta import AmedasStation

year = 2018
mon = 7
days = 31

sta = "Tokyo"
#sta = "Nagoya"
#sta = "Kumagaya"
#
title = "Daily timeseries of Jul. 2018"

# AmedasStation Classの初期化
amedas = AmedasStation(sta)
#
# AmedasStation.retrieve_dayメソッドを使い、データを取得
dat_i = amedas.retrieve_day(year, mon)
#
# 最高気温データの取り出し
tmax = dat_i.loc[:, 'tmax']

# 作図
# プロットエリアの定義
fig = plt.figure(figsize=(6, 3))
ax = fig.add_subplot(1, 1, 1)
# タイトルを付ける
plt.title(title + ',' + sta)
#

# 最高気温（C）
index = tmax.index
plt.xlim([1, days])
plt.ylim([math.floor(tmax.min() - 2), math.ceil(tmax.max()) + 5])
plt.plot(index, tmax, color='r', ls='-', label='Max. Temp.')
#
# 30度以上の日の領域を塗り潰す
plt.fill_between(index, np.zeros(len(index)), tmax, where=tmax >= 30,
                 color='r', alpha=0.4)
plt.ylabel('Temperature ($^{\circ}$C)')
#plt.xlabel('Year')
# y軸の目盛り
ax.yaxis.set_major_locator(ticker.AutoLocator())
ax.yaxis.set_minor_locator(ticker.AutoMinorLocator())
# x軸の目盛り
ax.xaxis.set_major_locator(ticker.AutoLocator())
ax.xaxis.set_minor_locator(ticker.AutoMinorLocator())
# 凡例
plt.legend(loc='best')
#
# グリッド線を描く
plt.grid(color='gray', ls=':')
#
# プロット範囲の調整
plt.subplots_adjust(hspace=0.8, bottom=0.2)
#
#
# ファイルへの書き出し
#fig_fname = "figure_day_" + sta + ".png"
fig_fname = "Fig4-1-3-1.png"
#fig_fname = "Fig4-1-3-2.png"
#fig_fname = "Fig4-1-3-3.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
#
plt.show()
