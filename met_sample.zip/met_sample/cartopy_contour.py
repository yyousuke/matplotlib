#!/usr/bin/env python3
import netCDF4
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import cartopy.crs as ccrs
from cartopy.mpl.ticker import LongitudeFormatter, LatitudeFormatter

# 緯度線、経度線を描く値
dlon, dlat = 30, 30
xticks = np.arange(-180, 180, dlon)
yticks = np.arange(-90, 90.1, dlat)
# 緯度線、経度線ラベルを描く値
dlon_lab, dlat_lab = 60, 30
xticks_lab = np.arange(-180, 180, dlon_lab)
yticks_lab = np.arange(-90, 90.1, dlat_lab)

# プロット領域の作成
fig = plt.figure()
# cartopy呼び出し：正距円筒図法（latlon相当）の準備
ax = fig.add_subplot(1, 1, 1, projection=ccrs.PlateCarree(central_longitude=180))

# 海岸線を描く
ax.coastlines()

# 経度、緯度線を描く
gl = ax.gridlines(crs=ccrs.PlateCarree(), draw_labels=False,
                  linewidth=1, linestyle=':', color='k', alpha=0.8)
gl.xlocator = mticker.FixedLocator(xticks)  # 経度線
gl.ylocator = mticker.FixedLocator(yticks)  # 緯度線

ax.set_xticks(xticks_lab, crs=ccrs.PlateCarree())  # 経度線ラベル
ax.set_yticks(yticks_lab, crs=ccrs.PlateCarree())  # 緯度線ラベル

# 目盛り線ラベルの表示形式を度数表記にする
ax.xaxis.set_major_formatter(LongitudeFormatter(zero_direction_label=True))
ax.yaxis.set_major_formatter(LatitudeFormatter())
# 目盛り線ラベルのサイズを指定
ax.axes.tick_params(labelsize=12)

# NetCDFデータの読み込み
file_name = "slp.mon.mean.nc"
nc = netCDF4.Dataset(file_name, 'r')
# データサイズの取得
idim = len(nc.dimensions['lon'])
jdim = len(nc.dimensions['lat'])
num_rec = len(nc.dimensions['time'])
datasize = idim * jdim  # size
print("num_lon =", idim, ", num_lat =", jdim, ", num_time =", num_rec)
print("datasize =", datasize)
# 変数の読み込み
lon = nc.variables["lon"][:]
lat = nc.variables["lat"][:]
time = nc.variables["time"][:]
slp = nc.variables["slp"][:]
# ファイルを閉じる
nc.close()
print("lon:", lon.shape)
print("lat:", lat.shape)
print("slp:", slp.shape)

# 1981〜2010年の７月平均値
tstr = (1981 - 1948) * 12 + 6
tend = (2010 - 1948 + 1) * 12
slp_jul = slp[tstr:tend:12, :, :].mean(axis=0)
#slp_jul = slp[6:12,:,:].mean(axis=0)
print("slp_jul:", slp_jul.shape)
#
# 経度・緯度座標の準備
x, y = np.meshgrid(lon - 180.0, lat)
print("x:", x.shape)
print("y:", y.shape)
#
# 等高線を描く
clevs = np.arange(np.floor(slp_jul.min() - np.fmod(slp_jul.min(), 20)),
                  np.ceil(slp_jul.max()) + 1, 4)
ax.contour(x, y, slp_jul, clevs, linewidths=0.8, colors='k')
#ax.contour(x, y, slp_jul, levels=clevs, linewidths=0.8, colors='k')

# ファイルへの書き出し
fig_fname = "Fig7-2-1.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
