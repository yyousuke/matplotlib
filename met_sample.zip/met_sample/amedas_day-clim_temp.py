#!/usr/bin/env python3
from pandas import Series, DataFrame
import numpy as np
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import math
from amesta import AmedasStation

year = 2018
mon = 7
days = 31

#sta = "Tokyo"
sta = "Nagoya"
#
title = "Daily timeseries of Jul. 2018"

# 日平均データの気候値を作成（1981〜2010年）
yr_sta = 1981
yr_end = 2010


def clim(var):
    # AmedasStation Classの初期化
    amedas = AmedasStation(sta)
    out = np.zeros(days)
    for yr in np.arange(yr_sta, yr_end + 1):
        # AmedasStation.retrieve_monメソッドを使い、データを取得し積算
        dat_i = amedas.retrieve_day(yr, mon)
        out_i = dat_i.loc[:, var]
        out = out + out_i
    return (out / len(np.arange(yr_sta, yr_end + 1)))


def main():
    # AmedasStation Classの初期化
    amedas = AmedasStation(sta)

    # AmedasStation.retrieve_monメソッドを使い、データを取得
    dat_i = amedas.retrieve_day(year, mon)
    #
    # 最低気温データの取り出し
    tmin = dat_i.loc[:, 'tmin']
    # 最高気温データの取り出し
    tmax = dat_i.loc[:, 'tmax']
    # 平均気温データの取り出し
    tave = dat_i.loc[:, 'tave']

    # 気候値データを取得
    tmax_c = clim('tmax')
    print(tmax_c)

    # 作図
    # (0) プロットエリアの定義
    #fig, ax1 = plt.subplots()
    fig = plt.figure(figsize=(6, 3))
    ax = fig.add_subplot(1, 1, 1)
    # タイトルを付ける
    plt.title(title + ',' + sta)
    #

    # 最高気温（C）
    index = tmax.index
    plt.xlim([1, days])
    plt.ylim([math.floor(tmin.min() - 2), math.ceil(tmax.max()) + 5])
    plt.plot(index, tmax, color='r', ls='-', label='Max. Temp.')
    #
    plt.fill_between(index, tmax_c, tmax, color='r', alpha=0.4)
    #
    ##plt.fill_between(index, np.ones(len(index))*30, tmax, color='r', alpha=0.4)
    #plt.fill_between(index, tmin, tmax, where=tmin<tmax, color='r', alpha=0.4)
    plt.ylabel('Temperature (C)')
    #plt.xlabel('Year')
    # y軸の目盛り
    ax.yaxis.set_major_locator(ticker.AutoLocator())
    ax.yaxis.set_minor_locator(ticker.AutoMinorLocator())
    # x軸の目盛り
    ax.xaxis.set_major_locator(ticker.AutoLocator())
    ax.xaxis.set_minor_locator(ticker.AutoMinorLocator())
    # 凡例
    plt.legend(loc='best')
    #
    # グリッド線を描く
    plt.grid(color='gray', ls=':')
    #
    # プロット範囲の調整
    plt.subplots_adjust(hspace=0.8, bottom=0.2)
    #
    #
    # ファイルへの書き出し
    fig_fname = "figure_day_" + sta + ".pdf"
    plt.savefig(fig_fname, dpi=300)
    #
    plt.show()


#
main()
