#!/usr/bin/env python3
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import math
from amesta import AmedasStation

# syear=None
# eyear=None
syear = 1900
eyear = 2024

sta = "Tokyo"
#
month = "jul"

title = "Yearly timeseries of July"

#
# AmedasStation Classの初期化
amedas = AmedasStation(sta)
# AmedasStation.retrieve_monメソッドを使い、最低気温データを取得
tmin_i = amedas.retrieve_mon("tmin")
#
# AmedasStation.retrieve_monメソッドを使い、最高気温データを取得
tmax_i = amedas.retrieve_mon("tmax")
#
# AmedasStation.retrieve_monメソッドを使い、平均気温データを取得
tave_i = amedas.retrieve_mon("tave")
#
# データの取り出し
tmin = tmin_i.loc[syear:eyear, month]
tmax = tmax_i.loc[syear:eyear, month]
tave = tave_i.loc[syear:eyear, month]

# 作図
# プロットエリアの定義
#fig, ax1 = plt.subplots()
fig = plt.figure(figsize=(6, 3))
ax = fig.add_subplot(1, 1, 1)
#
# タイトルを付ける
plt.title(title + ',' + sta)
#
#
# 気温（C）
index = tmin.index
# plt.ylim([math.floor(tmin.min()-math.fmod(tmin.min(),2)-2), math.ceil(tmax.max())+5])
plt.ylim([math.floor(tmin.min() - 2), math.ceil(tmax.max()) + 5])
plt.plot(index, tave, color='r', ls='-', label='Ave. Temp.')
plt.fill_between(index, tmin, tmax, color='r', alpha=0.4)
# plt.fill_between(index, tmin, tmax, where=tmin<tmax, color='r', alpha=0.4)
plt.ylabel('Temperature ($^{\circ}$C)')
#
# y軸の目盛り
ax.yaxis.set_major_locator(ticker.AutoLocator())
ax.yaxis.set_minor_locator(ticker.AutoMinorLocator())
# x軸の目盛り
ax.xaxis.set_major_locator(ticker.AutoLocator())
ax.xaxis.set_minor_locator(ticker.AutoMinorLocator())
# 凡例
plt.legend(loc='best')
#
# グリッド線を描く
plt.grid(color='gray', ls=':')
# プロット範囲の調整
plt.subplots_adjust(hspace=0.8, bottom=0.2)
#
# ファイルへの書き出し
fig_fname = "Fig4-1-2.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
#
plt.show()
