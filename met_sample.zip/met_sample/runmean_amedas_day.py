#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from pandas import Series, DataFrame
import numpy as np
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import math
from amesta import AmedasStation
#
plt.rcParams['xtick.direction'] = 'in'  # x軸目盛線を内側
plt.rcParams['xtick.major.width'] = 1.2  # x軸主目盛線の長さ
plt.rcParams['ytick.direction'] = 'in'  # y軸目盛線を内側
plt.rcParams['ytick.major.width'] = 1.2  # y軸主目盛線の長さ
plt.rcParams["legend.fancybox"] = False  # 凡例の角を丸くしない

year = 2019
mon = 2
days = 28

num = 5  # 移動平均の日数

sta = "Sapporo"
#
title = "Daily timeseries of Feb. 2019"

# AmedasStation Classの初期化
amedas = AmedasStation(sta)
#
# AmedasStation.retrieve_dayメソッドを使い、データを取得
dat_i = amedas.retrieve_day(year, mon)
#
# 最高気温データの取り出し
tmax = dat_i.loc[:, 'tmax']

# 作図
# プロットエリアの定義
fig = plt.figure(figsize=(6, 3))
ax = fig.add_subplot(1, 1, 1)
# タイトルを付ける
ax.set_title(title + ',' + sta, fontsize=20)
#
# 移動平均
y2 = np.convolve(tmax, np.ones(num) / num, mode='same')
#
# 作図範囲の指定
ax.set_xlim([1, days])
ax.set_ylim([math.floor(tmax.min() - 2), math.ceil(tmax.max()) + 5])
#
# 日最高気温（C）
index = tmax.index
ax.plot(index, tmax, color='r', ls='-', label='Max. Temp.')
# 移動平均した最高気温（C）
ax.plot(index, y2, color='gray', ls='--', label='Max. Temp. (5-days running mean)')
#
# 軸のラベル
ax.set_xlabel('Day', fontsize=16)
ax.set_ylabel('Temperature ($^{\circ}$C)', fontsize=16)

# y軸の目盛り
ax.yaxis.set_major_locator(ticker.AutoLocator())
ax.yaxis.set_minor_locator(ticker.AutoMinorLocator())
# x軸の目盛り
ax.xaxis.set_major_locator(ticker.AutoLocator())
ax.xaxis.set_minor_locator(ticker.AutoMinorLocator())
# 凡例
plt.legend(loc='best')
#
# グリッド線を描く
plt.grid(color='gray', ls=':')
# y=0の線を描く
plt.axhline(y=0, color='k', ls=':')
#
# プロット範囲の調整
plt.subplots_adjust(hspace=0.8, bottom=0.2)
#
#
# ファイルへの書き出し
fig_fname = "Fig5-5-9.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
#
plt.show()
