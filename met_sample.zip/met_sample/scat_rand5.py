#!/usr/bin/env python3
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
#print(plt.rcParams['lines.markersize'])
plt.rcParams['xtick.direction'] = 'in'  # x軸目盛線を内側
plt.rcParams['xtick.major.width'] = 1.2  # x軸大目盛線の長さ
plt.rcParams['ytick.direction'] = 'in'  # y軸目盛線を内側
plt.rcParams['ytick.major.width'] = 1.2  # y軸大目盛線の長さ

# サンプルサイズを設定
size_of_sample = 100

# 作図範囲の設定
xmin = -4
xmax = 4
ymin = -4
ymax = 4

# 軸のラベルとタイトルの設定
xlabel = 'x-axis'
ylabel = 'y-axis'
title = "Scatter diagram"

# 再現性を保つため、random stateを固定
np.random.seed(1900)
# ランダムデータの準備
data_x = np.random.randn(size_of_sample)
data_y = np.random.randn(size_of_sample)
data_z = np.random.randn(size_of_sample)

# プロットエリアの定義
#fig, ax1 = plt.subplots()
fig = plt.figure(figsize=(6, 6))
ax = fig.add_subplot(1, 1, 1)

# タイトルを付ける
plt.title(title, fontsize=20)

# 散布図
cs = plt.scatter(data_x, data_y, marker='o', s=24, c=data_z,
                 cmap='Blues', edgecolor='k')
#
# x軸、y軸の範囲
plt.xlim([xmin, xmax])
plt.ylim([ymin, ymax])
# x軸のラベル
plt.xlabel(xlabel, fontsize=16)
# y軸のラベル
plt.ylabel(ylabel, fontsize=16)
#
# 0の線を付ける
plt.axvline(x=0, color='k', ls=':')
plt.axhline(y=0, color='k', ls=':')
#
# カラーバーをつける
fig.colorbar(cs)
#
# x軸の目盛り
ax.xaxis.set_major_locator(ticker.MultipleLocator(1.0))
ax.xaxis.set_minor_locator(ticker.MultipleLocator(0.5))
# y軸の目盛り
ax.yaxis.set_major_locator(ticker.MultipleLocator(1.0))
ax.yaxis.set_minor_locator(ticker.MultipleLocator(0.5))
# グリッド線を描く
plt.grid(color='gray', ls=':')
# プロット範囲の調整
plt.subplots_adjust(hspace=0.8, bottom=0.2)
#
# ファイルへの書き出し
fig_fname = "Fig4-5-5.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
#
plt.show()
