#!/usr/bin/env python3
import matplotlib.pyplot as plt
import cartopy.crs as ccrs

# プロット領域の作成
fig = plt.figure()
# cartopy呼び出し
ax = fig.add_subplot(1, 1, 1, projection=ccrs.PlateCarree(central_longitude=180))
#ax = fig.add_subplot(1,1,1, projection=ccrs.PlateCarree())

# 海岸線を描く
ax.coastlines()

# ファイルへの書き出し
fig_fname = "Fig7-1-1.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
