#!/usr/bin/env python3
from pandas import Series, DataFrame
import pandas as pd
import numpy as np
import urllib.request
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import matplotlib.dates as mdates
from pandas.plotting import register_matplotlib_converters
register_matplotlib_converters()
plt.rcParams['xtick.direction'] = 'in'  # x軸目盛線を内側
plt.rcParams['xtick.major.width'] = 1.2  # x軸大目盛線の長さ
plt.rcParams['ytick.direction'] = 'in'  # y軸目盛線を内側
plt.rcParams['ytick.major.width'] = 1.2  # y軸大目盛線の長さ

# 年の範囲（大枠）
syear = 2000
eyear = 2019
# y軸の範囲の設定（大枠）
ymin = -8
ymax = 5
#
# 年の範囲（小枠）
syear_s = 2016
eyear_s = 2018
# y軸の範囲の設定（小枠）
ymin_s = -2.5
ymax_s = 2.5
#
# データの取得
retrieve = False
#retrieve = True

# 軸のラベルとタイトルの設定
xlabel = 'time'
ylabel = 'index'
title = "Timeseries of AO and NAO"

# AOI
url = "http://www.cpc.ncep.noaa.gov/products/precip/CWlink/daily_ao_index/monthly.ao.index.b50.current.ascii"
if retrieve:
    urllib.request.urlretrieve(url, "ao.txt")

# NAOI
url = "http://www.cpc.ncep.noaa.gov/products/precip/CWlink/pna/norm.nao.monthly.b5001.current.ascii"
if retrieve:
    urllib.request.urlretrieve(url, "nao.txt")

# ファイルから読み込み
dataset1 = pd.read_fwf("ao.txt", header=None, parse_dates=[[0, 1]],
                       index_col=[0], names=["year", "mon", "aoi"])
dataset2 = pd.read_fwf("nao.txt", header=None, parse_dates=[[0, 1]],
                       index_col=[0], names=["year", "mon", "naoi"])
#

# プロットエリアの定義
fig = plt.figure(figsize=(9, 6))
ax = fig.add_subplot(1, 1, 1)  # 大枠の作成

# タイトルを付ける
ax.set_title(title, fontsize=20)

# 作図
ax.plot(dataset1, color='r', label='AO')  # AO index
ax.plot(dataset2, color='b', label='NAO')  # NAO index
# x軸のラベル
ax.set_xlabel(xlabel, fontsize=16)
# y軸のラベル
ax.set_ylabel(ylabel, fontsize=16)
#
# 作図範囲の設定
ax.set_xlim([str(syear) + "-01-01", str(eyear) + "-12-31"])
ax.set_ylim([ymin, ymax])
#
ax.axhline(y=0, color='k', ls=':')  # y=0の線を付ける
ax.grid(color='gray', ls=':')  # グリッド線を描く
ax.legend(loc='best')  # 凡例を付ける
#
# x軸の目盛り
ax.xaxis.set_major_locator(ticker.AutoLocator())
ax.xaxis.set_minor_locator(ticker.AutoMinorLocator())
ax.xaxis.set_major_locator(ticker.FixedLocator(ax.get_xticks().tolist()))
ax.set_xticklabels(ax.get_xticklabels(), rotation=70, size="small")
ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y/%m'))
ax.xaxis.set_minor_formatter(ticker.NullFormatter())
# y軸の目盛り
ax.yaxis.set_major_locator(ticker.AutoLocator())
ax.yaxis.set_minor_locator(ticker.AutoMinorLocator())

# 小枠の作成
ax2 = plt.axes([0.20, 0.27, 0.3, 0.2])  # 小枠
# 作図
ax2.plot(dataset1, color='r', label='AO')  # AO index
ax2.plot(dataset2, color='b', label='NAO')  # NAO index
# 作図範囲の設定
ax2.set_xlim([str(syear_s) + "-01-01", str(eyear_s) + "-12-31"])
ax2.set_ylim([ymin_s, ymax_s])
#
ax2.axhline(y=0, color='k', ls=':')  # y=0の線を付ける
ax2.grid(color='gray', ls=':')  # グリッド線を描く
#
# x軸の目盛り
ax2.xaxis.set_major_locator(ticker.AutoLocator())
ax2.xaxis.set_minor_locator(ticker.AutoMinorLocator())
ax2.xaxis.set_major_locator(ticker.FixedLocator(ax2.get_xticks().tolist()))
ax2.set_xticklabels(ax2.get_xticklabels(), rotation=70, size="small")
ax2.xaxis.set_major_formatter(mdates.DateFormatter('%y/%m'))
ax2.xaxis.set_minor_formatter(ticker.NullFormatter())
# y軸の目盛り
ax2.yaxis.set_major_locator(ticker.AutoLocator())
ax2.yaxis.set_minor_locator(ticker.AutoMinorLocator())

# プロット範囲の調整
plt.subplots_adjust(hspace=0.8, bottom=0.2)

# ファイルへの書き出し
fig_fname = "Fig4-6-6.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
