#!/usr/bin/env python3
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import math
import numpy as np
from amesta import AmedasStation

# 平均と標準偏差を計算する期間
syear = 1960
eyear = 2022

# ビンの端点の設定
edges = np.arange(0, 540, 20)
# 作図範囲の設定
xmin = 0
xmax = 540
ymin = 0
ymax = None

# 地点
sta = "Tokyo"
# 月
month1 = "jun"
month2 = "jul"

xlabel = 'Precipitation (mm)'
ylabel = 'Frequency'
title = "Histogram of Jun-Jul Precipitation"

# 作図オプションのリスト
STYLES = [
    dict(color=['g', 'b'], alpha=0.4, edgecolor='k',
         histtype='bar', label="histtype='bar'"),
    dict(color=['g', 'b'], alpha=0.4, edgecolor='k',
         histtype='barstacked', label="histtype='barstacked'"),
    dict(color=['g', 'b'], alpha=0.4, edgecolor='k',
         histtype='step', label="histtype='step'"),
    dict(color=['g', 'b'], alpha=0.4, edgecolor='k',
         histtype='stepfilled', label="histtype='stepfilled'")
]

# プロットエリアの定義
fig = plt.figure(figsize=(8, 6))
#
# タイトルを付ける
plt.axis('off')
plt.title(title + ',' + sta)
#
# AmedasStation Classの初期化
amedas = AmedasStation(sta)
# AmedasStation.retrieve_monメソッドを使い、降水量データを取得
prep_i = amedas.retrieve_mon("prep")
#
#
# データの取り出し
# 降水量(mm)
prep1 = prep_i.loc[syear:eyear, month1]
prep2 = prep_i.loc[syear:eyear, month2]
#
for n in np.arange(4):
    # サブプロット作成
    ax = fig.add_subplot(2, 2, n + 1)
    # ヒストグラム
    ax.hist([prep1, prep2], density=True, bins=edges, **STYLES[n])
    # グリッド線を描く
    ax.grid(color='gray', ls=':')
    # x軸の目盛り
    ax.xaxis.set_major_locator(ticker.MultipleLocator(100))
    ax.xaxis.set_minor_locator(ticker.MultipleLocator(20))
    #ax.xaxis.set_major_locator(ticker.AutoLocator())
    #ax.xaxis.set_minor_locator(ticker.AutoMinorLocator())
    # y軸の目盛り
    ax.yaxis.set_major_locator(ticker.AutoLocator())
    ax.yaxis.set_minor_locator(ticker.AutoMinorLocator())
    # x軸、y軸の範囲
    plt.xlim([xmin, xmax])
    plt.ylim([ymin, ymax])
    #
    # 凡例
    plt.legend(loc='best')
    if n >= 2:
        # x軸のラベル
        plt.xlabel(xlabel)
    if not n % 2:
        # y軸のラベル
        plt.ylabel(ylabel)
#
# プロット範囲の調整
plt.subplots_adjust(top=None, bottom=0.2, wspace=0.2, hspace=0.15)
#plt.subplots_adjust(hspace=0.8, bottom=0.2)
#
# ファイルへの書き出し
fig_fname = "Fig4-4-13.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
#
plt.show()
