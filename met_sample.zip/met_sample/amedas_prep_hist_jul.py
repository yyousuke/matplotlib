#!/usr/bin/env python3
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import math
import numpy as np
from amesta import AmedasStation

# 平均と標準偏差を計算する期間
syear = 1960
eyear = 2021

# ビンの端点の設定
edges = np.arange(0, 400, 20)
# 作図範囲の設定
xmin = 0
xmax = 400
ymin = 0
ymax = None

# 地点
sta = "Tokyo"
# 月
month = "jul"

xlabel = 'Precipitation (mm)'
ylabel = 'Frequency'
title = "Histogram of July Precipitation"

# 作図オプションのリスト
STYLES = [
    dict(color='b', alpha=0.4, edgecolor='k', label=str(month).capitalize())
]

# AmedasStation Classの初期化
amedas = AmedasStation(sta)
# AmedasStation.retrieve_monメソッドを使い、降水量データを取得
prep_i = amedas.retrieve_mon("prep")
#
#
# データの取り出し
# 降水量(mm)
prep = prep_i.loc[syear:eyear, month]
# 平均、分散の計算
prepm = prep.mean()
prepsd = prep.std()
print("mean = ", prepm)
print("SD = ", prepsd)
print("median = ", prep.median())
print("skewness = ", prep.skew())
print("kurtosis = ", prep.kurtosis())

# 作図
# プロットエリアの定義
#fig, ax1 = plt.subplots()
fig = plt.figure(figsize=(6, 6))
ax = fig.add_subplot(1, 1, 1)
#
# タイトルを付ける
plt.title(title + ',' + sta)
#
#
# ヒストグラム
plt.hist(prep, density=True, bins=edges, **STYLES[0])
#ax.hist(prep, bins='auto') #
#ax.hist(prep, bins='auto', orientation="horizontal") #
#
# x軸、y軸の範囲
plt.xlim([xmin, xmax])
plt.ylim([ymin, ymax])
#
# x軸のラベル
plt.xlabel(xlabel)
# y軸のラベル
plt.ylabel(ylabel)
# x軸の目盛り
ax.xaxis.set_major_locator(ticker.AutoLocator())
ax.xaxis.set_minor_locator(ticker.AutoMinorLocator())
# y軸の目盛り
ax.yaxis.set_major_locator(ticker.AutoLocator())
ax.yaxis.set_minor_locator(ticker.AutoMinorLocator())
#
# 凡例
plt.legend(loc='best')
#
# グリッド線を描く
plt.grid(color='gray', ls=':')
# プロット範囲の調整
plt.subplots_adjust(hspace=0.8, bottom=0.2)
#
# ファイルへの書き出し
fig_fname = "Fig4-4-8.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
#
plt.show()
