#!/usr/bin/env python3
import matplotlib.pyplot as plt
from matplotlib import gridspec

#
# プロットエリアの定義
fig = plt.figure(figsize=(8, 7))
# GridSpecを使いサブプロット生成
gs = gridspec.GridSpec(3, 3, height_ratios=(2, 2, 1), width_ratios=(3, 3, 1))
ax = [plt.subplot(gs[0, :]), \
      plt.subplot(gs[1, 0]), plt.subplot(gs[1, 1]), plt.subplot(gs[2, 0]), \
      plt.subplot(gs[1:, 2]) ]

# テキストの表示
ax[0].text(0.5, 0.5, "gs[0, :]", ha='center', va='center')
ax[1].text(0.5, 0.5, "gs[1, 0]", ha='center', va='center')
ax[2].text(0.5, 0.5, "gs[1, 1]", ha='center', va='center')
ax[3].text(0.5, 0.5, "gs[2, 0]", ha='center', va='center')
ax[4].text(0.5, 0.5, "gs[1:, 2]", ha='center', va='center')

# プロット範囲の調整
#plt.subplots_adjust(top=None, bottom=0.1, wspace=0.10, hspace=0.10)
#plt.subplots_adjust(top=None, bottom=0.1, wspace=0.25, hspace=0.20)
#plt.subplots_adjust(hspace=0.8,bottom=0.2)

# ファイルへの書き出し
fig_fname = "Fig4-6-4.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
