#!/usr/bin/env python3
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import math
import numpy as np
from amesta import AmedasStation

# 平均と標準偏差を計算する期間
syear = 1960
eyear = 2024

# ビンの端点の設定
edges = np.arange(0, 541, 20)
# 作図範囲の設定
xmin = 0
xmax = 540
ymin = 0
ymax = None

# 地点
sta = "Tokyo"
# 月のリスト
months = ["jun", "jul", "aug"]

xlabel = 'Precipitation (mm)'
ylabel = 'Frequency'
title = "Histogram of July Precipitation"

# 作図オプションのリスト
STYLES = [
   dict(color=['g', 'b', 'aqua'], alpha=0.4, edgecolor='k', \
      label=[str(months[0]).capitalize(), str(months[1]).capitalize(), str(months[2]).capitalize()])
]
STYLESK = [
    dict(color='g', label=str(months[0]).capitalize() + "_kde"),
    dict(color='b', label=str(months[1]).capitalize() + "_kde"),
    dict(color='aqua', label=str(months[2]).capitalize() + "_kde")
]

# AmedasStation Classの初期化
amedas = AmedasStation(sta)
# AmedasStation.retrieve_monメソッドを使い、降水量データを取得
prep_i = amedas.retrieve_mon("prep")
#
#
# データの取り出し
# 降水量(mm)
prep = list()
for n in np.arange(3):
    prep.append(prep_i.loc[syear:eyear, months[n]])

# 作図
# プロットエリアの定義
fig = plt.figure(figsize=(6, 6))
ax = fig.add_subplot(1, 1, 1)
#
# タイトルを付ける
plt.title(title + ',' + sta)
#
#
# ヒストグラム
plt.hist([prep[0], prep[1], prep[2]], density=True, bins=edges, **STYLES[0])
for n in np.arange(3):
    prep[n].plot(kind='kde', **STYLESK[n])
#
# x軸、y軸の範囲
plt.xlim([xmin, xmax])
plt.ylim([ymin, ymax])
#
# x軸のラベル
plt.xlabel(xlabel)
# y軸のラベル
plt.ylabel(ylabel)
# x軸の目盛り
ax.xaxis.set_major_locator(ticker.MultipleLocator(100))
ax.xaxis.set_minor_locator(ticker.MultipleLocator(20))
# y軸の目盛り
ax.yaxis.set_major_locator(ticker.AutoLocator())
ax.yaxis.set_minor_locator(ticker.AutoMinorLocator())
#
# 凡例
plt.legend(loc='best')
#
# グリッド線を描く
plt.grid(color='gray', ls=':')
# プロット範囲の調整
plt.subplots_adjust(hspace=0.8, bottom=0.2)
#
# ファイルへの書き出し
fig_fname = "Fig4-4-11.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
#
plt.show()
