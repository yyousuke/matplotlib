#!/usr/bin/env python3
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
plt.rcParams['xtick.direction'] = 'in'  # x軸目盛線を内側
plt.rcParams['xtick.major.width'] = 1.2  # x軸大目盛線の長さ
plt.rcParams['ytick.direction'] = 'in'  # y軸目盛線を内側
plt.rcParams['ytick.major.width'] = 1.2  # y軸大目盛線の長さ

# サンプルサイズを設定
size_of_sample = 50
mu_xs = 5, -5, 5, -5  # x軸上の平均値
mu_ys = 5, 5, -5, -5  # y軸上の平均値
# 誤差の標準偏差の指定
sigma_x = 1.0
sigma_y = 1.0

# 作図範囲の設定
xmin = None
xmax = None
ymin = None
ymax = None

# 軸のラベルとタイトルの設定
xlabel = 'x-axis'
ylabel = 'y-axis'
title = "Scatter diagram"

# 再現性を保つため、random stateを固定
np.random.seed(1900)
# ランダムデータの準備
data_x = np.array(list())
data_y = np.array(list())
for mu_x, mu_y in zip(mu_xs, mu_ys):
    data_xi = mu_x + sigma_x * np.random.randn(size_of_sample)
    data_yi = mu_y + sigma_y * np.random.randn(size_of_sample)
    data_x = np.append(data_x, data_xi)
    data_y = np.append(data_y, data_yi)

# プロットエリアの定義
fig = plt.figure(figsize=(6, 6))
ax = fig.add_subplot(1, 1, 1)

# タイトルを付ける
plt.title(title, fontsize=20)

# 散布図
plt.scatter(data_x, data_y, color='r', edgecolor='k', marker='o',
            s=24, alpha=0.4)

#
# x軸、y軸の範囲
plt.xlim([xmin, xmax])
plt.ylim([ymin, ymax])
# x軸のラベル
plt.xlabel(xlabel, fontsize=16)
# y軸のラベル
plt.ylabel(ylabel, fontsize=16)
#
# x軸の目盛り
ax.xaxis.set_major_locator(ticker.AutoLocator())
ax.xaxis.set_minor_locator(ticker.AutoMinorLocator())
# y軸の目盛り
ax.yaxis.set_major_locator(ticker.AutoLocator())
ax.yaxis.set_minor_locator(ticker.AutoMinorLocator())

# 相関係数の出力
corr = np.corrcoef(data_x, data_y)
name = "{s:s}{f:.3f}".format(s="r = ", f=corr[1, 0])
print(name)
# 軸の範囲の取得
xmin, xmax, ymin, ymax = plt.axis()
print(xmin, xmax, ymin, ymax)
xloc = xmin + 0.05 * (xmax - xmin)  # x軸上の座標
yloc = ymax - 0.05 * (ymax - ymin)  # y軸上の座標
print(xloc, yloc)
# 相関係数を表示
plt.text(xloc, yloc, name, fontsize=14, color='k')

#
# グリッド線を描く
plt.grid(color='gray', ls=':')
# プロット範囲の調整
plt.subplots_adjust(hspace=0.8, bottom=0.2)
#
# ファイルへの書き出し
fig_fname = "Fig4-5-14-3.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
#
plt.show()
