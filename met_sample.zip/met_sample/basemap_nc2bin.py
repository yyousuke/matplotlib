#!/usr/bin/env python3
import urllib.request
import netCDF4
import numpy as np

# データ取得の有無
retrieve = True
#retrieve = False

# URL
url = "http://database.rish.kyoto-u.ac.jp/arch/ncep/data/ncep.reanalysis.derived/surface/slp.mon.mean.nc"
file_name = "slp.mon.mean.nc"
#
# ファイルのダウンロード
if retrieve:
    urllib.request.urlretrieve(url, file_name)

# NetCDFデータの読み込み
nc = netCDF4.Dataset(file_name, 'r')

# データサイズの取得
idim = len(nc.dimensions['lon'])
jdim = len(nc.dimensions['lat'])
ndim = len(nc.dimensions['time'])
datasize = idim * jdim  # size
#print("lon = ", idim, ", lat = ", jdim, ", time = ", ndim)

# 変数の読み込み
lon = nc.variables["lon"][:]
lat = nc.variables["lat"][:]
time = nc.variables["time"][:]
var = nc.variables["slp"][:]

# ファイルを閉じる
nc.close()

# バイナリファイル書き出し
np.array(var).tofile("output.bin")
#print(len(var))

# バイナリファイル読み込み（Little endian）
din = np.fromfile("output.bin", dtype='<f4')
#din = np.fromfile("output.bin", dtype='>f4')
#print(len(din))
slp = din.reshape(ndim, jdim, idim)
print("slp data (nc) = ")
print(slp)
#print(len(slp))
