#!/usr/bin/env python3
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

# サンプルデータ
x = (1.0, 1.25, 1.5, 1.75, 2.0)
y = (1.5, 1.5, 1.5, 1.5, 1.5)
u = (-35.0, -35.0, -35.0, -35.0, -35.0)
v = (25.0, 25.0, 25.0, 25.0, 25.0)
n = ("headlength=3", "headlength=4", "headlength=5", "headlength=6", "headlength=7")

#
# プロットエリアの定義
fig = plt.figure(figsize=(7, 1.5))
ax = fig.add_subplot(1, 1, 1)
ax.set_xlim([0.85, 2.15])
ax.set_ylim([1.0, 2.0])

# 矢羽を描
plt.quiver(x[0], y[0], u[0], v[0], color='k', headlength=3)
plt.quiver(x[1], y[1], u[1], v[1], color='k', headlength=4)
plt.quiver(x[2], y[2], u[2], v[2], color='r', headlength=5)
plt.quiver(x[3], y[3], u[3], v[3], color='k', headlength=6)
plt.quiver(x[4], y[4], u[4], v[4], color='k', headlength=7)

# x軸の目盛り
ax.xaxis.set_major_locator(ticker.NullLocator())
ax.xaxis.set_minor_locator(ticker.NullLocator())
# y軸の目盛り
ax.yaxis.set_major_locator(ticker.NullLocator())
ax.yaxis.set_minor_locator(ticker.NullLocator())

# テキストをプロット
for x1, y1, u1, v1, name in zip(x, y, u, v, n):
    plt.text(x1, y1 - 0.4, name, ha='center', va='center', fontsize=9)
    print(x1, y1, u1, v1)

# ファイルへの書き出し
fig_fname = "Fig5-1-16.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
