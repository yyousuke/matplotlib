#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from PIL import Image

#
# プロットエリアの定義
fig = plt.figure(figsize=(5, 5))
ax = fig.add_subplot(1, 1, 1)

# 画像を読み込み
im = Image.open("Fig5-4-10.png")
# arrayに変換
X = np.asarray(im)

# 画像を表示
plt.imshow(X, aspect='auto')

# x軸の目盛り
ax.xaxis.set_major_locator(ticker.NullLocator())
ax.xaxis.set_minor_locator(ticker.NullLocator())
# y軸の目盛り
ax.yaxis.set_major_locator(ticker.NullLocator())
ax.yaxis.set_minor_locator(ticker.NullLocator())
#ax.yaxis.set_major_locator(ticker.AutoLocator())
#ax.yaxis.set_minor_locator(ticker.AutoLocator())

# ファイルへの書き出し
fig_fname = "Fig5-5-1.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
