#!/usr/bin/env python3
import matplotlib.pyplot as plt
import numpy as np
#print(plt.rcParams['lines.markersize'])

# サンプルサイズを設定
size_of_sample = 100

# 作図範囲の設定
xmin = -4
xmax = 4
ymin = -4
ymax = 4

# 軸のラベルとタイトルの設定
xlabel = 'x-axis'
ylabel = 'y-axis'
title = "Scatter diagram"

# 再現性を保つため、random stateを固定
np.random.seed(1900)
# ランダムデータの準備
data_x = np.random.randn(size_of_sample)
data_y = np.random.randn(size_of_sample)
data_z = np.random.randn(size_of_sample)

# プロットエリアの定義
fig = plt.figure(figsize=(6, 6))
ax = fig.add_subplot(1, 1, 1)

# タイトルを付ける
plt.title(title)

# 散布図
plt.scatter(data_x, data_y, marker='o', s=24, c=data_z, cmap='Blues')
#
# x軸、y軸の範囲
plt.xlim([xmin, xmax])
plt.ylim([ymin, ymax])
# x軸のラベル
plt.xlabel(xlabel)
# y軸のラベル
plt.ylabel(ylabel)
#
# グリッド線を描く
plt.grid(color='gray', ls=':')
# プロット範囲の調整
plt.subplots_adjust(hspace=0.8, bottom=0.2)
#
# ファイルへの書き出し
fig_fname = "Fig4-5-4.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
#
plt.show()
