#!/usr/bin/env python3
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np

title = "Histogram"

# 再現性を保つため、random stateを固定
np.random.seed(1900)
# ランダムデータの準備
hist_y = np.random.randn(1000)

# プロットエリアの定義
fig = plt.figure(figsize=(6, 6))
ax = fig.add_subplot(1, 1, 1)

# タイトルを付ける
plt.title(title)

# ヒストグラム
plt.hist(hist_y, bins='auto')

#
# グリッド線を描く
plt.grid(color='gray', ls=':')
# プロット範囲の調整
plt.subplots_adjust(hspace=0.8, bottom=0.2)
#
# ファイルへの書き出し
fig_fname = "Fig4-4-1.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
#
plt.show()
