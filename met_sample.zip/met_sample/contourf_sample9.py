#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from matplotlib.colors import LogNorm
import matplotlib as mpl
import copy

# x, y軸サンプルデータ
n = 200
x = np.linspace(-10, 10, n)
y = np.linspace(-10, 10, n)

# x, y軸メッシュデータ
X, Y = np.meshgrid(x, y)
# z軸データ
Z = np.sqrt(X**2 + Y**2)
#
# プロットエリアの定義
fig = plt.figure(figsize=(5, 5))
ax = fig.add_subplot(1, 1, 1)

# 色テーブルの設定
cmap = copy.copy(mpl.cm.get_cmap('bwr')) # 色テーブル取得
#cmap = plt.get_cmap('bwr')  # 色テーブル取得
cmap.set_under('gray')  # 下限を下回った場合の色を指定
cmap.set_over('w')  # 上限を超えた場合の色を指定
#
# 陰影を付ける
levels = np.arange(np.floor(Z.min()), np.ceil(Z.max()) + 1, 1.5)
plt.contourf(X, Y, Z, cmap=cmap, norm=LogNorm())
#plt.contourf(X, Y, Z, levels=levels, cmap=cmap, vmin=3, vmax=9)

# カラーバーを付ける
cbar = plt.colorbar(shrink=0.8)
cbar.set_label('label', fontsize=14)

# グリッド線を付ける
plt.grid(color='gray', ls='--')
# 縦横比を調整
plt.gca().set_aspect('equal')

# x軸の目盛り
ax.xaxis.set_major_locator(ticker.AutoLocator())
ax.xaxis.set_minor_locator(ticker.AutoLocator())
# y軸の目盛り
ax.yaxis.set_major_locator(ticker.AutoLocator())
ax.yaxis.set_minor_locator(ticker.AutoLocator())

# ファイルへの書き出し
fig_fname = "Fig5-3-9.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
