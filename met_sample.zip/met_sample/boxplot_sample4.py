#!/usr/bin/env python3
import pandas as pd
#import numpy as np
import urllib.request
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
plt.rcParams['xtick.direction'] = 'in'  # x軸目盛線を内側
plt.rcParams['xtick.major.width'] = 1.2  # x軸大目盛線の長さ
plt.rcParams['ytick.direction'] = 'in'  # y軸目盛線を内側
plt.rcParams['ytick.major.width'] = 1.2  # y軸大目盛線の長さ

# 年の範囲
#syear = 1950
syear = 2010
eyear = 2018
retrieve = False

# 軸のラベルとタイトルの設定
xlabel = ''
ylabel = 'Index'
title = "Boxplot"

# AOI
url = "http://www.cpc.ncep.noaa.gov/products/precip/CWlink/daily_ao_index/monthly.ao.index.b50.current.ascii"
if retrieve:
    urllib.request.urlretrieve(url, "ao.txt")

# NAOI
url = "http://www.cpc.ncep.noaa.gov/products/precip/CWlink/pna/norm.nao.monthly.b5001.current.ascii"
if retrieve:
    urllib.request.urlretrieve(url, "nao.txt")

# PNAI
url = "http://www.cpc.ncep.noaa.gov/products/precip/CWlink/pna/norm.pna.monthly.b5001.current.ascii"
if retrieve:
    urllib.request.urlretrieve(url, "pna.txt")

# ファイルから読み込み
dataset1 = pd.read_fwf("ao.txt", header=None, parse_dates=[[0, 1]],
                       index_col=[0], names=["year", "mon", "aoi"])
dataset2 = pd.read_fwf("nao.txt", header=None, parse_dates=[[0, 1]],
                       index_col=[0], names=["year", "mon", "naoi"])
dataset3 = pd.read_fwf("pna.txt", header=None, parse_dates=[[0, 1]],
                       index_col=[0], names=["year", "mon", "pnai"])
#
# 入力データの作成
data_x1 = dataset1.loc[str(syear) + "-01-01":str(eyear) + "-12-31", "aoi"]
data_x2 = dataset2.loc[str(syear) + "-01-01":str(eyear) + "-12-31", "naoi"]
data_x3 = dataset3.loc[str(syear) + "-01-01":str(eyear) + "-12-31", "pnai"]

# プロットエリアの定義
fig = plt.figure(figsize=(6, 6))
ax = fig.add_subplot(1, 1, 1)

# タイトルを付ける
plt.title(title, fontsize=20)

# 箱ひげ図
ax.boxplot((data_x1, data_x2, data_x3), whis=100,
           showmeans=True, patch_artist=True)
ax.set_xticklabels(["AO index", "NAO index", "PNA index"])  # x軸の目盛り線ラベル
ax.grid(color='gray', ls=':')  # グリッド線を描く

# x軸のラベル
ax.set_xlabel(xlabel, fontsize=16)
# y軸のラベル
ax.set_ylabel(ylabel, fontsize=16)
#
# x軸の目盛り
#ax.xaxis.set_major_locator(ticker.AutoLocator())
#ax.xaxis.set_minor_locator(ticker.AutoMinorLocator())
# y軸の目盛り
ax.yaxis.set_major_locator(ticker.AutoLocator())
ax.yaxis.set_minor_locator(ticker.AutoMinorLocator())
# 作図範囲の設定
#ax.set_xlim([-5, 5])
#ax.set_ylim([-5, 5])

# 凡例を描く
#plt.legend(loc='best')
# プロット範囲の調整
plt.subplots_adjust(hspace=0.8, bottom=0.2)

# ファイルへの書き出し
fig_fname = "Fig5-4-5.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
