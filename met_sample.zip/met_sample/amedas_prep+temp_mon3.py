#!/usr/bin/env python3
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import math
import numpy as np
from pandas import Series
from amesta import AmedasStation
plt.rcParams['ytick.direction'] = 'in'
plt.rcParams['ytick.major.width'] = 1.2
plt.rcParams["legend.fancybox"] = False

# 平均と標準偏差を計算する期間
syear = 1960
eyear = 2019

# 地点名
sta = "Tokyo"
#
# 月のリスト
months = [
    "jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct",
    "nov", "dec"
]

title = "Precipitation & Temperature"

# AmedasStation Classの初期化
amedas = AmedasStation(sta)
# AmedasStation.retrieve_monメソッドを使い、降水量データを取得
prep_i = amedas.retrieve_mon("prep")
# AmedasStation.retrieve_monメソッドを使い、平均気温データを取得
tave_i = amedas.retrieve_mon("tave")
#
# x軸のindex
index = np.arange(len(months)) + 1.0
#
# データの取り出し
# 降水量(mm)
prepm = list()
prepsd = list()
# 気温(℃)
tempm = list()
tmin = list()
tmax = list()
# 軸の範囲、ラベル
max_yl = list()
max_yr = list()
min_yr = list()
xlabel = list()
for n in np.arange(len(months)):
    # 月間降水量
    prep = prep_i.loc[syear:eyear, months[n]]
    # 月平均気温
    temp = tave_i.loc[syear:eyear, months[n]]
    # 平均、標準偏差の計算
    prepm.append(prep.mean())
    prepsd.append(prep.std())
    tempm.append(temp.mean())
    tmin.append(temp.mean() - temp.std())
    tmax.append(temp.mean() + temp.std())
    # y軸上の最大値
    max_yl.append(math.ceil(prep.mean() + prep.std()))
    max_yr.append(math.ceil(temp.mean() + temp.std()))
    # y軸上の最小値
    min_yr.append(math.floor(temp.mean() - temp.std()))
    # x軸の目盛り
    xlabel.append(str(months[n]).capitalize())
print("prep mean = ", prepm)
print("prep SD = ", prepsd)
print("temp mean = ", tempm)
print("temp min. = ", tmin)
print("temp max. = ", tmax)

# 作図
# プロットエリアの定義
fig = plt.figure(figsize=(6, 3))
ax1 = fig.add_subplot(1, 1, 1)
#
# タイトルを付ける
plt.title(title + ',' + sta)
#
#
# 作図範囲の設定
plt.xlim([0.5, len(months) + 0.5])
#plt.ylim([0, np.max(max_yl)+50])
plt.ylim([0, 390])
#
# 棒グラフ
error_config = {'ecolor': '0.3', 'capsize': 6}
p1 = plt.bar(index, prepm, yerr=prepsd, error_kw=error_config, \
        color='b', width=0.4, alpha=0.4)
l1 = 'Mean Precipitation'
# y軸のラベル
plt.ylabel('Precipitation (mm)')
# グリッド線を描く
plt.grid(color='gray', ls=':')
# y軸の目盛り
ax1.yaxis.set_major_locator(ticker.MultipleLocator(100))
ax1.yaxis.set_minor_locator(ticker.MultipleLocator(20))
# x軸の目盛り
ax1.set_xticks(np.arange(len(months)) + 1)
ax1.set_xticklabels(xlabel)
#
# 折れ線グラフ
ax2 = ax1.twinx()  # 2つのプロットを関連付ける（x軸の共有）
# 作図範囲の設定
plt.ylim([0, 39])
#plt.ylim([np.min(min_yr)-5, np.max(max_yr)+5])
#
# 折れ線グラフ
p2 = plt.plot(index, tempm, color='r', ls='-')
l2 = 'Mean Temperature'
# １σの範囲
plt.fill_between(index, tmin, tmax, color='r', alpha=0.4)
# y軸のラベル
plt.ylabel('Temperature ($^{\circ}$C)')
# y軸の目盛り
ax2.yaxis.set_major_locator(ticker.MultipleLocator(10))
ax2.yaxis.set_minor_locator(ticker.MultipleLocator(2))
#
# 凡例
plt.legend((p1[0], p2[0]), (l1, l2), loc='upper left')
#
# プロット範囲の調整
plt.subplots_adjust(hspace=0.8, bottom=0.2)
#
# ファイルへの書き出し
fig_fname = "Fig4-3-3.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
#
plt.show()
