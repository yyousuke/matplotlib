#!/usr/bin/env python3
import pandas as pd

input_file = "20190826-20190828-amedas_prep.csv"

# データ読み込み
df = pd.read_csv(input_file, parse_dates=[0], index_col=[0], skiprows=[0, 1])
#print(df)

# データ取り出し
lons = df.iloc[0, :]  # 経度
lats = df.iloc[1, :]  # 緯度
prep = df.iloc[2:, :]  # 降水量(mm)

print(prep)
print(prep.shape)

print(df.iloc[0:2, :].T)
#print(df.iloc[0:2,:])
