#!/usr/bin/env python3
import netCDF4
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import cartopy.crs as ccrs
from cartopy.mpl.ticker import LongitudeFormatter, LatitudeFormatter
import warnings
warnings.filterwarnings('ignore')

# 緯度線、経度線を描く値
dlon, dlat = 30, 30
xticks = np.arange(-180, 180, dlon)
yticks = np.arange(-90, 90.1, dlat)
# 緯度線、経度線ラベルを描く値
dlon_lab, dlat_lab = 60, 30
xticks_lab = np.arange(-180, 180, dlon_lab)
yticks_lab = np.arange(-90, 90.1, dlat_lab)

# プロット領域の作成
fig = plt.figure()
# cartopy呼び出し：正距円筒図法（latlon相当）の準備
ax = fig.add_subplot(1, 1, 1, projection=ccrs.PlateCarree(central_longitude=180))

# 海岸線を描く
ax.coastlines()

# 経度、緯度線を描く
gl = ax.gridlines(crs=ccrs.PlateCarree(), draw_labels=False,
                  linewidth=1, linestyle=':', color='k', alpha=0.8)
gl.xlocator = mticker.FixedLocator(xticks)  # 経度線
gl.ylocator = mticker.FixedLocator(yticks)  # 緯度線

ax.set_xticks(xticks_lab, crs=ccrs.PlateCarree())  # 経度線ラベル
ax.set_yticks(yticks_lab, crs=ccrs.PlateCarree())  # 緯度線ラベル

# 目盛り線ラベルの表示形式を度数表記にする
ax.xaxis.set_major_formatter(LongitudeFormatter(zero_direction_label=True))
ax.yaxis.set_major_formatter(LatitudeFormatter())
# 目盛り線ラベルのサイズを指定
ax.axes.tick_params(labelsize=12)

# 読み込むファイル名と変数名
file_names = ["slp.mon.mean.nc", "uwnd.mon.mean.nc", "vwnd.mon.mean.nc"]
var_names = ["slp", "uwnd", "vwnd"]
d = list()
for file_name, var_name in zip(file_names, var_names):
    # NetCDFデータの読み込み
    nc = netCDF4.Dataset(file_name, 'r')
    # 変数の読み込み
    lon = nc.variables["lon"][:]
    lat = nc.variables["lat"][:]
    time = nc.variables["time"][:]
    d.append(nc.variables[var_name][:])
    # ファイルを閉じる
    nc.close()

# 1981〜2010年の７月平均値
tstr = (1981 - 1948) * 12 + 6
tend = (2010 - 1948 + 1) * 12
slp = d[0][tstr:tend:12, :, :].mean(axis=0)
u = d[1][tstr:tend:12, :, :].mean(axis=0)
v = d[2][tstr:tend:12, :, :].mean(axis=0)
#
# 経度・緯度座標の準備
x, y = np.meshgrid(lon - 180.0, lat)
#
# 等高線を描く
clevs = np.arange(np.floor(slp.min() - np.fmod(slp.min(), 20)),
                  np.ceil(slp.max()) + 1, 4)
cs = ax.contour(x, y, slp, clevs, linewidths=0.8, colors='k')

# ラベルを付ける
clevels = cs.levels
cs.clabel(clevels[::5], fontsize=12, fmt="%d")

# 矢羽を描く
ax.barbs(x[::3, ::3], y[::3, ::3], u[::3, ::3], v[::3, ::3],
         sizes=dict(emptybarb=0.0), length=4, color='r')

# ファイルへの書き出し
fig_fname = "Fig7-3-1.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
