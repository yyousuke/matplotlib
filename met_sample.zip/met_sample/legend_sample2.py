#!/usr/bin/env python3
from pandas import Series, DataFrame
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.ticker as ticker
from pandas.plotting import register_matplotlib_converters
register_matplotlib_converters()
# 表示項目数の設定
pd.set_option("display.max_columns", 50)
#pd.set_option("display.max_rows",50)
#
plt.rcParams['xtick.direction'] = 'in'  # x軸目盛線を内側
plt.rcParams['xtick.major.width'] = 1.2  # x軸主目盛線の長さ
plt.rcParams['ytick.direction'] = 'in'  # y軸目盛線を内側
plt.rcParams['ytick.major.width'] = 1.2  # y軸主目盛線の長さ
plt.rcParams["legend.fancybox"] = False  # 凡例の角を丸くしない

# 入力ファイル名
input_file = "ssw_info.txt"

# x軸の範囲
stime = "2018-12-10"
etime = "2019-01-10"

title = "Zonal Wind and Temperature Difference"  # タイトル
ylab1 = "10 hPa 60$^{\circ}$N Zonal Wind (m/s)"  # 左側のラベル
ylab2 = "10 hPa T(90N) - T(60N) (K)"  # 右側のラベル
l0 = "Zonal Wind"  # 凡例のラベル（東西風）
l1 = "T(90N) - T(60N)"  # 凡例のラベル（気温差）

# 矢印の日付とラベル
ssw_info = [
    (datetime(2018, 12, 17, 0, 0, 0), "minor warming", 0),
    (datetime(2018, 12, 19, 0, 0, 0), "minor warming", 0),
    (datetime(2018, 12, 25, 0, 0, 0), "minor warming", 0),
    (datetime(2019, 1, 2, 0, 0, 0), "major warming", 0)
]

# datasetの読み込み
col_names = ('rec_num', 'ref_year', 'year', 'month', 'day', 'ihh', 'time', 'u',
             't', 'tdiff', 'flg1', 'flg2', 'flg3', 'flg4', 'flg5')
dataset = pd.read_fwf(input_file, header=None, parse_dates=[[2, 3, 4]],
                      index_col=[0], names=col_names, keep_date_col=True)
print(dataset)

ax = list()
# プロットエリアの定義
fig = plt.figure(figsize=(9, 5))
ax.append(fig.add_subplot(1, 1, 1))
# タイトルを付ける
ax[0].set_title(title, fontsize=24)

# 東西風の折れ線グラフ
p0 = ax[0].plot(dataset.index, dataset.u, color='k', label=l0)  #
ax[0].set_ylabel(ylab1, fontsize=16)  # y軸のラベル
ax[0].set_ylim([-30, 50])
#ax[0].legend(loc='best') # 凡例
#

# 気温の折れ線グラフ
ax.append(ax[0].twinx())  # 2つのプロットを関連付ける
p1 = ax[1].plot(dataset.index, dataset.tdiff, color='r', label=l1)  #
ax[1].set_ylabel(ylab2, fontsize=16)  # y軸のラベル
ax[1].set_ylim([-30, 50])
#ax[1].legend(loc='best') # 凡例

# 矢印とラベルを付ける
for date, label, hour in ssw_info:
    ax[1].annotate(label,
                   xy=(date + timedelta(hours=hour),
                       dataset.loc[date, "u"] - 1),
                   xytext=(date + timedelta(hours=hour),
                           dataset.loc[date, "u"] - 8),
                   arrowprops=dict(facecolor='k'),
                   horizontalalignment='center',
                   verticalalignment='top')

for n in np.arange(2):
    # x軸の目盛り
    ax[n].xaxis.set_major_locator(ticker.AutoLocator())
    ax[n].xaxis.set_minor_locator(ticker.AutoMinorLocator())
    ax[n].xaxis.set_minor_formatter(ticker.NullFormatter())
    # y軸の目盛り
    ax[n].yaxis.set_major_locator(ticker.AutoLocator())
    ax[n].yaxis.set_minor_locator(ticker.AutoMinorLocator())
    # 作図範囲の設定
    ax[n].set_xlim([stime, etime])
    #
    ax[n].set_xlabel('')  # X軸のラベル
    ax[n].axhline(y=0, color='k', ls=':')  # y=0の線を付ける
    ax[n].grid(color='gray', ls=':')  # グリッド線を描く

# 下の文字列
ax[0].set_xticklabels(ax[0].get_xticklabels(), rotation=70, size="small")
ax[0].xaxis.set_major_formatter(mdates.DateFormatter('%Y/%m/%d'))

# 凡例
plt.legend((p0[0], p1[0]), (l0, l1), loc='upper right', bbox_to_anchor=(1, 1),
           borderaxespad=0)

# プロット範囲の調整
plt.subplots_adjust(hspace=0.8, bottom=0.2)

# ファイルへの書き出し
fig_fname = "Fig5-6-3.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
