#!/usr/bin/env python3
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
from pandas import Series

# サンプルサイズを設定
size_of_sample = 1000

# ビンの端点の設定
edges = np.arange(-4.5, 4.6, 0.5)

# 作図範囲の設定
xmin = -4.5
xmax = 4.5
ymin = 0
ymax = 300

# 作図オプションのリスト
STYLES = [
    dict(alpha=0.4, fill=False, hatch='//'),
    dict(alpha=0.4, fill=False, hatch='++'),
    dict(alpha=0.4, edgecolor='k', fill=False, hatch='xx'),
    dict(alpha=1.0, edgecolor='k', fill=False, hatch='oo')
]

# プロットエリアの定義
fig = plt.figure(figsize=(6, 6))

hist_y = list()
ax = list()
for n in np.arange(4):
    # ランダムデータの準備
    hist_y.append(np.random.randn(size_of_sample))
    # サブプロット作成
    ax.append(fig.add_subplot(2, 2, n + 1))
    # ヒストグラム
    ax[n].hist(hist_y[n], bins=edges, **STYLES[n])
    # グリッド線を描く
    ax[n].grid(color='gray', ls=':')
    # x軸の目盛り
    ax[n].xaxis.set_major_locator(ticker.AutoLocator())
    ax[n].xaxis.set_minor_locator(ticker.AutoMinorLocator())
    # x軸、y軸の範囲
    plt.xlim([xmin, xmax])
    plt.ylim([ymin, ymax])
    # 統計量の表示
    print("mean = ", Series(hist_y[n]).mean())
    print("SD = ", Series(hist_y[n]).std())
    print("median = ", Series(hist_y[n]).median())
    print("skewness = ", Series(hist_y[n]).skew())
    print("kurtosis = ", Series(hist_y[n]).kurtosis())

# プロット範囲の調整
plt.subplots_adjust(top=None, bottom=0.1, wspace=0.2, hspace=0.15)
#
# ファイルへの書き出し
fig_fname = "Fig4-4-4.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
#
plt.show()
