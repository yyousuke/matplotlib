#!/usr/bin/env python3
from pandas import Series, DataFrame
import pandas as pd
import numpy as np
import urllib.request
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
plt.rcParams['xtick.direction'] = 'in'  # x軸目盛線を内側
plt.rcParams['xtick.major.width'] = 1.2  # x軸大目盛線の長さ
plt.rcParams['ytick.direction'] = 'in'  # y軸目盛線を内側
plt.rcParams['ytick.major.width'] = 1.2  # y軸大目盛線の長さ

# 年の範囲
# syear = 1950
syear = 2010
eyear = 2023
retrieve = False

# 軸のラベルとタイトルの設定
xlabel = 'AO'
ylabel = 'NAO'
title = "Scatter diagram"

# AOI
url = "http://www.cpc.ncep.noaa.gov/products/precip/CWlink/daily_ao_index/monthly.ao.index.b50.current.ascii"
if retrieve:
    urllib.request.urlretrieve(url, "ao.txt")

# NAOI
url = "http://www.cpc.ncep.noaa.gov/products/precip/CWlink/pna/norm.nao.monthly.b5001.current.ascii"
if retrieve:
    urllib.request.urlretrieve(url, "nao.txt")

# ファイルから読み込み
dataset1 = pd.read_fwf("ao.txt", header=None, parse_dates=[[0, 1]],
                       index_col=[0], names=["year", "mon", "aoi"])
dataset2 = pd.read_fwf("nao.txt", header=None, parse_dates=[[0, 1]],
                       index_col=[0], names=["year", "mon", "naoi"])
#
# 入力データの作成
data_x = dataset1.loc[str(syear) + "-01-01":str(eyear) + "-12-31", "aoi"]
data_y = dataset2.loc[str(syear) + "-01-01":str(eyear) + "-12-31", "naoi"]
# print(data_x)
# print(data_y)

# プロットエリアの定義
fig = plt.figure(figsize=(6, 6))
ax = fig.add_subplot(1, 1, 1)

# タイトルを付ける
plt.title(title, fontsize=20)

# 作図
plt.scatter(data_x, data_y, color='r', marker='o', s=24, edgecolor='k',
            label='original', zorder=3)  # 散布図
# plt.legend(loc='best') # 凡例
# x軸のラベル
plt.xlabel(xlabel, fontsize=16)
# y軸のラベル
plt.ylabel(ylabel, fontsize=16)
#
# x軸の目盛り
ax.xaxis.set_major_locator(ticker.AutoLocator())
ax.xaxis.set_minor_locator(ticker.AutoMinorLocator())
# y軸の目盛り
ax.yaxis.set_major_locator(ticker.AutoLocator())
ax.yaxis.set_minor_locator(ticker.AutoMinorLocator())
# 作図範囲の設定
ax.set_xlim([-5, 5])
ax.set_ylim([-5, 5])

# 相関係数の出力
corr = np.corrcoef(data_x, data_y)
name = "{s:s}{f:.3f}".format(s="r = ", f=corr[1, 0])
# print(corr)
# name = "r=%4.3f" % corr[1,0]
# 軸の範囲の取得
xmin, xmax, ymin, ymax = plt.axis()
xloc = xmin + 0.05 * (xmax - xmin)  # x軸上の座標
yloc = ymax - 0.05 * (ymax - ymin)  # y軸上の座標
# 相関係数を表示
plt.text(xloc, yloc, name, fontsize=14, color='k')
#
ax.axvline(x=0, color='k', ls=':', zorder=1)  # x=0の線を付ける
ax.axhline(y=0, color='k', ls=':', zorder=1)  # y=0の線を付ける
ax.grid(color='gray', ls=':')  # グリッド線を描く

# 回帰式の係数
a = corr[1, 0] * data_y.std() / data_x.std()
b = data_y.mean() - a * data_x.mean()
name = "{s1:s}{f1:.3f}{s2:s}{f2:.3f}".format(s1="y = ", f1=a, s2="x + ", f2=b)
xloc = xmin + 0.05 * (xmax - xmin)  # x軸上の座標
yloc = ymax - 0.10 * (ymax - ymin)  # y軸上の座標
print(name)
# 回帰式の計算
x1 = np.linspace(np.floor(xmin), np.ceil(xmax), len(data_x))
y1 = a * x1 + b
# 回帰式のプロット
plt.plot(x1, y1, color='k', lw=3, label='linear fit', zorder=2)
# 回帰式を表示
plt.text(xloc, yloc, name, fontsize=14, color='k')

# 凡例を描く
plt.legend(loc='lower right')
# plt.legend(loc='best')
# プロット範囲の調整
# plt.subplots_adjust(top=None, bottom=0.1, wspace=0.25, hspace=0.20)
plt.subplots_adjust(hspace=0.8, bottom=0.2)

# ファイルへの書き出し
fig_fname = "Fig4-5-16.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
