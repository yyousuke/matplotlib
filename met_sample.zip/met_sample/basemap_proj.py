#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap

# プロット領域の作成
fig = plt.figure(figsize=(6, 9))

for n in np.arange(6):
    ax = fig.add_subplot(3, 2, n + 1)
    # Basemap呼び出し
    if n == 0:
        # デフォルト(latlon, 正距円筒図法)
        m = Basemap(projection='cyl', lon_0=180, lat_0=0)
        ax.set_title("projection='cyl'")
    elif n == 1:
        # 正射投影図法
        m = Basemap(projection='ortho', lon_0=180, lat_0=45)
        #m = Basemap(projection='ortho', lon_0=180, lat_0=70)
        ax.set_title("projection='ortho'")
    elif n == 2:
        # メルカトル図法
        m = Basemap(projection='merc', llcrnrlon=0, urcrnrlon=360,
                    llcrnrlat=-60, urcrnrlat=60)
        ax.set_title("projection='merc'")
    elif n == 3:
        # ランベルト正角円錐図法
        m = Basemap(projection='lcc', lon_0=180, lat_0=50,
                    width=3e7, height=1.5e7)
        ax.set_title("projection='lcc'")
    elif n == 4:
        # 極投影図法（北極）
        m = Basemap(projection='npstere', lon_0=180, boundinglat=20)
        ax.set_title("projection='npstere'")
    elif n == 5:
        # 極投影図法（南極）
        m = Basemap(projection='spstere', lon_0=180, boundinglat=-20)
        ax.set_title("projection='spstere'")

        # ロビンソン図法
#        m = Basemap(projection='robin', lon_0=180, lat_0=70, resolution='l')
#        ax.set_title("projection='robin'")

# 海岸線を描く
    m.drawcoastlines(color='k')

    # 背景に色を付ける
    m.drawmapboundary(fill_color='aqua')

    # 大陸に色を付ける
    m.fillcontinents(color='w')

    # 緯度線を引く
    m.drawparallels(np.arange(-90, 90, 30), color="gray")
    #m.drawparallels(np.arange(-90,90,30), color="gray", fontsize='small',
    #   labels=[True,False,False,False])

    # 経度線を引く
    m.drawmeridians(np.arange(0, 360, 30), color="gray")
    #m.drawmeridians(np.arange(0,360,30), color="gray", fontsize='small',
    #   labels=[False,False,False,True])
    #m.bluemarble(scale=0.5)

# プロット範囲の調整
plt.subplots_adjust(top=0.85, bottom=0.25, wspace=0.15, hspace=0.10)

# ファイルへの書き出し
fig_fname = "Fig6-2-1.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
