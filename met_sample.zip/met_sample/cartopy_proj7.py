#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from cartopy.mpl.ticker import LongitudeFormatter, LatitudeFormatter
import warnings
warnings.filterwarnings('ignore')

# 緯度線、経度線を描く値
dlon, dlat = 30, 30
xticks = np.arange(-180, 180, dlon)
yticks = np.arange(-90, 90.1, dlat)

# プロット領域の作成
fig = plt.figure()
# cartopy呼び出し
# モルワイデ図法
ax = fig.add_subplot(1, 1, 1,
                     projection=ccrs.Mollweide(central_longitude=180.0))
ax.set_title("projection='ccrs.Mollweide'")

# 経度、緯度線を描く
gl = ax.gridlines(crs=ccrs.PlateCarree(), draw_labels=False,
                  linewidth=1, linestyle=':', color='k', alpha=0.8)
gl.xlocator = mticker.FixedLocator(xticks)  # 経度線
gl.ylocator = mticker.FixedLocator(yticks)  # 緯度線

# 陸・海・川・湖を塗り分けて描く
ax.add_feature(cfeature.LAND)
ax.add_feature(cfeature.OCEAN)
ax.add_feature(cfeature.COASTLINE, linewidth=0.8)
ax.add_feature(cfeature.LAKES)
#ax.add_feature(cfeature.LAKES, alpha=0.5)
ax.add_feature(cfeature.RIVERS)

# ファイルへの書き出し
fig_fname = "Fig7-4-8.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
