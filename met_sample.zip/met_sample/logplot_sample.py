#!/usr/bin/env python3
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
#
plt.rcParams['xtick.direction'] = 'in'  # x軸目盛線を内側
plt.rcParams['xtick.major.width'] = 1.2  # x軸大目盛線の長さ
plt.rcParams['ytick.direction'] = 'in'  # y軸目盛線を内側
plt.rcParams['ytick.major.width'] = 1.2  # y軸大目盛線の長さ

# 入力ファイル名
input_file = "20190126-21UTC_Tateno.csv"

# x軸、y軸のラベル
xlabel = "Temperature ($\mathrm{^\circ}$C)"
ylabel = "Pressure (hPa)"

# x軸、y軸の範囲
xmin = None
xmax = None
ymin = 1000
ymax = 100

# データの読み込み (ファイルから)
dataset = pd.read_csv(input_file, index_col=[0])
#print(dataset)
#print(dataset.loc[:,"temp"])
#print(dataset.index)

# 気圧
pres = dataset.index
# 気温
temp = dataset.loc[:, "temp"]

#
# プロットエリアの定義
fig = plt.figure(figsize=(5, 6))
ax = fig.add_subplot(1, 1, 1)

# 折れ線グラフ
ax.plot(temp, pres, color='k')
ax.set_yscale("log")

# プロット範囲の定義
ax.set_xlim([xmin, xmax])
ax.set_ylim([ymin, ymax])

# x軸のラベル
ax.set_xlabel(xlabel, fontsize=16)
# y軸のラベル
ax.set_ylabel(ylabel, fontsize=16)

# グリッド線を付ける
ax.grid(color='gray', ls='--')

# x軸の目盛り
ax.xaxis.set_major_locator(ticker.AutoLocator())
ax.xaxis.set_minor_locator(ticker.AutoLocator())
#
# y軸の目盛り
ax.yaxis.set_major_locator(ticker.AutoLocator())
ax.yaxis.set_minor_locator(ticker.AutoLocator())

# ファイルへの書き出し
fig_fname = "Fig5-5-6.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
