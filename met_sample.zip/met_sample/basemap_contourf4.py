#!/usr/bin/env python3
import netCDF4
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap

# プロット領域の作成
fig = plt.figure()

# Basemap呼び出し
# 正距円筒図法（latlon相当）の準備（low resolutionの海岸線）
m = Basemap(projection='cyl', llcrnrlat=-90, urcrnrlat=90, llcrnrlon=0,
            urcrnrlon=360, resolution='l')

# 海岸線を描く
m.drawcoastlines(linewidth=0.2, color='k')

# 背景に色を付ける
#m.drawmapboundary(fill_color='aqua')

# 大陸に色を付ける
#m.fillcontinents(color='w', lake_color='b')

# 経度線を引く
m.drawmeridians(np.arange(0, 360, 30), color="0.9", fontsize='small',
                labels=[False, False, False, True])

# 緯度線を引く
m.drawparallels(np.arange(-90, 90, 30), color="0.9", fontsize='small',
                labels=[True, False, False, False])

# NetCDFデータの読み込み
file_name = "slp.mon.mean.nc"
nc = netCDF4.Dataset(file_name, 'r')
# データサイズの取得
idim = len(nc.dimensions['lon'])
jdim = len(nc.dimensions['lat'])
num_rec = len(nc.dimensions['time'])
datasize = idim * jdim  # size
print("num_lon =", idim, ", num_lat =", jdim, ", num_time =", num_rec)
print("datasize =", datasize)
# 変数の読み込み
lon = nc.variables["lon"][:]
lat = nc.variables["lat"][:]
time = nc.variables["time"][:]
slp = nc.variables["slp"][:]
# ファイルを閉じる
nc.close()
print("lon:", lon.shape)
print("lat:", lat.shape)
print("slp:", slp.shape)

# 1981〜2010年の７月平均値
tstr = (1981 - 1948) * 12 + 6
tend = (2010 - 1948 + 1) * 12
slp_jul = slp[tstr:tend:12, :, :].mean(axis=0)
#slp_jul = slp[6:12,:,:].mean(axis=0)
print("slp_jul:", slp_jul.shape)
#
# 経度・緯度座標の準備
lons, lats = np.meshgrid(lon, lat)
print("lats:", lats.shape)
print("lons:", lons.shape)
# 図法の経度、緯度に変換する（NetCDFデータの緯度・経度の単位は度）
x, y = m(lons, lats)
#x, y = m(lons*180./np.pi, lats*180./np.pi)
#
# 等高線を描く
clevs = np.arange(np.floor(slp_jul.min() - np.fmod(slp_jul.min(), 20)),
                  np.ceil(slp_jul.max()) + 1, 4)
cs = m.contour(x, y, slp_jul, clevs, linewidths=0.8, colors='k')

# ラベルを付ける
clevels = cs.levels
cs.clabel(clevels[::5], fontsize=12, fmt="%d")

# 2018年７月の偏差
n = (2018 - 1948) * 12 + 6
slp_anom = slp[n, :, :] - slp_jul
# 陰影を描く
work = max(np.abs(np.floor(slp_anom.min())), np.abs(np.ceil(slp_anom.max())))
clevs = np.arange(-(work + 1), work + 1)
# 色テーブルの設定
cmap = plt.get_cmap('bwr')  # 色テーブル取得
m.contourf(x, y, slp_anom, clevs, cmap=cmap)

# カラーバーを付ける
cbar = plt.colorbar(shrink=0.8, orientation='vertical')
cbar.set_label('SLP anom. in Jul. 2018', fontsize=14)

# ファイルへの書き出し
fig_fname = "Fig6-5-10.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
