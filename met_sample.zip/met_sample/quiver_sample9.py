#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

# オプションリスト
STYLES = [
    dict(minlength=0.5, color='k'),
    dict(minlength=1, color='r'),
    dict(minlength=5, color='k'),
    dict(minlength=10, color='k'),
]
# サンプルデータ
x = (1.0, 1.25, 1.5, 1.75, 2.0)
y = (1.5, 1.5, 1.5, 1.5, 1.5)
u = (5.0, 10.0, 15.0, 20.0, 25.0)
v = (0.0, 0.0, 0.0, 0.0, 0.0)

#
# プロットエリアの定義
fig = plt.figure(figsize=(7, 5))
# 軸の定義
ax = list()
for n in np.arange(len(STYLES)):
    ax.append(fig.add_subplot(len(STYLES), 1, n + 1))
    # x軸の範囲
    plt.xlim([0.9, 2.2])
    # タイトルを付ける
    plt.title("minlength=" + str(STYLES[n]['minlength']), color=STYLES[n]['color'])
    # 矢羽を描く
    plt.quiver(x, y, u, v, **STYLES[n])

    # x軸の目盛り
    ax[n].xaxis.set_major_locator(ticker.NullLocator())
    ax[n].xaxis.set_minor_locator(ticker.NullLocator())
    # y軸の目盛り
    ax[n].yaxis.set_major_locator(ticker.NullLocator())
    ax[n].yaxis.set_minor_locator(ticker.NullLocator())

    # 東西風速、南北風速をテキストとしてプロット
    for x1, y1, u1, v1 in zip(x, y, u, v):
        name = "{s1:s}{f1:2.0f}{s2:s}{f2:2.0f}{s3:s}".format(s1="(", \
          f1=u1, s2=", ", f2=v1, s3=")")
        plt.text(x1, y1 - 0.05, name, ha='center', va='center', fontsize=9)
        print(x1, y1, u1, v1)

# プロット範囲の調整
#plt.subplots_adjust(hspace=0.9,bottom=0.2)
plt.subplots_adjust(top=None, bottom=0.15, wspace=0.25, hspace=0.35)
# ファイルへの書き出し
fig_fname = "Fig5-1-19.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
