#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import urllib.request
from PIL import Image
#
time = "201902151100"
# 赤外画像
title_ir = "Infrared (" + time + ")"
url_ir = "https://www.jma.go.jp/jp/gms/imgs/0/infrared/1/" + time + "-00.png"
# 可視画像
title_vis = "Visible (" + time + ")"
url_vis = "https://www.jma.go.jp/jp/gms/imgs_c/0/visible/1/" + time + "-00.png"

# 画像を読み込み
im = list()
im.append(Image.open(urllib.request.urlopen(url_ir)))
im.append(Image.open(urllib.request.urlopen(url_vis)))

# タイトルの設定
title = list()
title.append(title_ir)
title.append(title_vis)

# プロットエリアの定義
fig = plt.figure(figsize=(5, 7))

ax = list()
for n in np.arange(len(im)):
    # 軸の追加
    ax.append(fig.add_subplot(len(im), 1, n + 1))
    # 画像を表示
    ax[n].imshow(im[n], aspect='equal')
    #plt.imshow(im[n], aspect='auto')
    # x軸の目盛り
    ax[n].xaxis.set_major_locator(ticker.NullLocator())
    ax[n].xaxis.set_minor_locator(ticker.NullLocator())
    # y軸の目盛り
    ax[n].yaxis.set_major_locator(ticker.NullLocator())
    ax[n].yaxis.set_minor_locator(ticker.NullLocator())
    # タイトルを付ける
    ax[n].set_title(title[n])

# プロット範囲の調整
plt.subplots_adjust(top=None, bottom=0.15, wspace=0.25, hspace=0.15)
#plt.subplots_adjust(hspace=0.8,bottom=0.2)

# ファイルへの書き出し
fig_fname = "Fig5-5-2.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
