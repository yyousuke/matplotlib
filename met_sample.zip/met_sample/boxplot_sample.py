#!/usr/bin/env python3
import pandas as pd
#import numpy as np
import urllib.request
import matplotlib.pyplot as plt

# 年の範囲
syear = 2010
eyear = 2018
retrieve = False

# 軸のラベルとタイトルの設定
xlabel = ''
ylabel = 'AO Index'
title = "Boxplot"

# AOI
url = "http://www.cpc.ncep.noaa.gov/products/precip/CWlink/daily_ao_index/monthly.ao.index.b50.current.ascii"
if retrieve:
    urllib.request.urlretrieve(url, "ao.txt")

# ファイルから読み込み
dataset = pd.read_fwf("ao.txt", header=None, parse_dates=[[0, 1]],
                      index_col=[0], names=["year", "mon", "aoi"])
#
# 入力データの作成
data_x = dataset.loc[str(syear) + "-01-01":str(eyear) + "-12-31", "aoi"]

# プロットエリアの定義
fig = plt.figure(figsize=(6, 6))
ax = fig.add_subplot(1, 1, 1)

# タイトルを付ける
plt.title(title, fontsize=20)

# 箱ひげ図
plt.boxplot(data_x)

# x軸のラベル
ax.set_xlabel(xlabel, fontsize=16)
# y軸のラベル
ax.set_ylabel(ylabel, fontsize=16)
#
# x軸の目盛り
#ax.xaxis.set_major_locator(ticker.AutoLocator())
#ax.xaxis.set_minor_locator(ticker.AutoMinorLocator())
# y軸の目盛り
#ax.yaxis.set_major_locator(ticker.AutoLocator())
#ax.yaxis.set_minor_locator(ticker.AutoMinorLocator())
# 作図範囲の設定
#ax.set_xlim([-5, 5])
#ax.set_ylim([-5, 5])

# 凡例を描く
#plt.legend(loc='best')
# プロット範囲の調整
plt.subplots_adjust(hspace=0.8, bottom=0.2)

# ファイルへの書き出し
fig_fname = "Fig5-4-1.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
