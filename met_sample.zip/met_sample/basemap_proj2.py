#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap

# プロット領域の作成
fig = plt.figure(figsize=(6, 9))

for n in np.arange(5):
    ax = fig.add_subplot(3, 2, n + 1)
    # Basemap呼び出し
    if n == 0:
        # モルワイデ図法
        m = Basemap(projection='moll', lon_0=180, lat_0=0)
        ax.set_title("projection='moll'")
    elif n == 1:
        # ロビンソン図法
        m = Basemap(projection='robin', lon_0=180)
        ax.set_title("projection='robin'")
    elif n == 2:
        # ランベルト正積円筒図法
        m = Basemap(projection='cea')
        ax.set_title("projection='cea'")
    elif n == 3:
        # ミラー図法
        m = Basemap(projection='mill', lon_0=180)
        ax.set_title("projection='mill'")
    elif n == 4:
        # 正距方位図法
        m = Basemap(projection='aeqd', lon_0=140, lat_0=35)
        ax.set_title("projection='aeqd'")

    # 海岸線を描く
    m.drawcoastlines(color='k')

    # 背景に色を付ける
    m.drawmapboundary(fill_color='aqua')

    # 大陸に色を付ける
    m.fillcontinents(color='w')

    # 緯度線を引く
    m.drawparallels(np.arange(-90, 90, 30), color="gray")
    #m.drawparallels(np.arange(-90,90,30), color="gray", fontsize='small',
    #   labels=[True,False,False,False])

    # 経度線を引く
    m.drawmeridians(np.arange(0, 360, 30), color="gray")
    #m.drawmeridians(np.arange(0,360,30), color="gray", fontsize='small',
    #   labels=[False,False,False,True])
    #m.bluemarble(scale=0.5)

# プロット範囲の調整
plt.subplots_adjust(top=0.85, bottom=0.25, wspace=0.15, hspace=0.10)

# ファイルへの書き出し
fig_fname = "Fig6-2-2.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
