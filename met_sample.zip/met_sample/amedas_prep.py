#!/usr/bin/env python3
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import math
from amesta import AmedasStation

#syear=None
#eyear=None
syear = 1960
eyear = 2021

sta = "Tokyo"
#
month = "jul"

title = "Yearly timeseries of July"

# AmedasStation Classの初期化
amedas = AmedasStation(sta)
# AmedasStation.retrieve_monメソッドを使い、降水量データを取得
prep_i = amedas.retrieve_mon("prep")
#
#
# データの取り出し
# 降水量(mm)
prep = prep_i.loc[syear:eyear, month]

# 作図
# プロットエリアの定義
#fig, ax1 = plt.subplots()
fig = plt.figure(figsize=(6, 3))
ax = fig.add_subplot(1, 1, 1)
#
# タイトルを付ける
plt.title(title + ',' + sta)
#
#
#
index = prep.index
plt.ylim([0, math.ceil(prep.max()) + 50])
plt.bar(index, prep, color='b', width=0.4, alpha=0.4, label='Precipitation')
plt.ylabel('Precipitation (mm)')
#
# y軸の目盛り
ax.yaxis.set_major_locator(ticker.AutoLocator())
ax.yaxis.set_minor_locator(ticker.AutoMinorLocator())
# x軸の目盛り
ax.xaxis.set_major_locator(ticker.AutoLocator())
ax.xaxis.set_minor_locator(ticker.AutoMinorLocator())
# 凡例
plt.legend(loc='best')
#
# グリッド線を描く
plt.grid(color='gray', ls=':')
# プロット範囲の調整
plt.subplots_adjust(hspace=0.8, bottom=0.2)
#
# ファイルへの書き出し
fig_fname = "Fig4-2-1.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
#
plt.show()
