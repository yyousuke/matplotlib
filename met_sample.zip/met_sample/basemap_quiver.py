#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap

# プロット領域の作成
fig = plt.figure()

# Basemap呼び出し
# ランベルト正角円錐図法
m = Basemap(projection='lcc', lat_0=35, lon_0=135, width=8000000, height=6000000)

# 海岸線を描く
m.drawcoastlines(linewidth=0.2, color='k')

# 背景に色を付ける
#m.drawmapboundary(fill_color='aqua')

# 大陸に色を付ける
#m.fillcontinents(color='w', lake_color='b')

# 経度線を引く
m.drawmeridians(np.arange(0, 360, 10), color="0.9", fontsize='small',
                labels=[False, False, False, True])

# 緯度線を引く
m.drawparallels(np.arange(-90, 90, 10), color="0.9", fontsize='small',
                labels=[True, False, False, False])

# データの読み込み
idim = 144
jdim = 73
datasize = idim * jdim
# SLP
din = np.fromfile("output.bin", dtype='<f4', count=datasize)
slp = din.reshape(jdim, idim)
print(slp.shape)
print(slp.min(), slp.max())
# u
din = np.fromfile("output_uwnd.bin", dtype='<f4', count=datasize)
u = din.reshape(jdim, idim)
# V
din = np.fromfile("output_vwnd.bin", dtype='<f4', count=datasize)
v = din.reshape(jdim, idim)
#
# 経度・緯度座標の準備
nlats = jdim
nlons = idim
delta = 360. / (nlons - 1)
lats = (90. - delta * np.indices((nlats, nlons))[0, :, :])
lons = (delta * np.indices((nlats, nlons))[1, :, :])
# 図法の経度、緯度に変換する
x, y = m(lons, lats)
#
# 等値線を描く
#clevs = [980, 990, 1000, 1010, 1020]
clevs = np.arange(980, 1040, 4)
m.contour(x, y, slp, clevs, linewidths=0.8, colors='k')
#m.contour(x, y, slp, levels=clevs, linewidths=0.8, colors='k')

# 矢印を描く
m.quiver(x[::3, ::3], y[::3, ::3], u[::3, ::3], v[::3, ::3])

# ファイルへの書き出し
fig_fname = "Fig6-5-20.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
