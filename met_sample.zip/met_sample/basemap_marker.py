#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap

# プロット領域の作成
fig = plt.figure()

# Basemap呼び出し
# ランベルト正角円錐図法
m = Basemap(projection='lcc', lat_0=35, lon_0=135, llcrnrlat=10, urcrnrlat=60,
            llcrnrlon=100, urcrnrlon=180)

# 海岸線を描く
m.drawcoastlines(color='k')

# 背景に色を付ける
m.drawmapboundary(fill_color='aqua')

# 大陸に色を付ける
m.fillcontinents(color='w')

# 緯度線を引く
m.drawparallels(np.arange(-90, 90, 5), color="gray", fontsize='small',
                labels=[True, False, False, False])

# 経度線を引く
m.drawmeridians(np.arange(0, 360, 5), color="gray", fontsize='small',
                labels=[False, False, False, True])

# マーカーを描く経度・緯度・都市名
lats = [43.06, 35.69, 25.08, 39.9, 53.02]
lons = [141.328, 139.75, 121.55, 116.38, 158.65]
cities = ['Sapporo', 'Tokyo', 'Taipei', 'Beiging', 'Petropavlovsk']
#
# 図法の座標へ変換
x, y = m(lons, lats)
#
# マーカーをプロット
for xc, yc in zip(x, y):
    m.plot(xc, yc, marker='^', color='b', markersize=9)
    #m.plot(xc, yc, "b^", markersize=9)
#
# 都市名をプロット
for name, xpt, ypt in zip(cities, x, y):
    plt.text(xpt - 100000, ypt + 30000, name, fontsize=9, color='b',
             ha='right', va='center')

# ファイルへの書き出し
fig_fname = "Fig6-3-5.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
