#!/usr/bin/env python3
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
plt.rcParams['xtick.direction'] = 'in'  # x軸目盛線を内側
plt.rcParams['xtick.major.width'] = 1.2  # x軸主目盛線の長さ
plt.rcParams['ytick.direction'] = 'in'  # y軸目盛線を内側
plt.rcParams['ytick.major.width'] = 1.2  # y軸主目盛線の長さ

# サンプルサイズを設定
size_of_sample = 50
# 平均、標準偏差の指定
mu1, sigma1 = 50, 10
mu2, sigma2 = 30, 4

# 作図範囲の設定
xmin = None
xmax = None
ymin = None
ymax = None

# 軸のラベルとタイトルの設定
xlabel = 'x-axis'
ylabel = 'y-axis'
title = "Scatter diagram"

# 再現性を保つため、random stateを固定
np.random.seed(1900)
# ランダムデータの準備
data_x1 = mu1 + sigma1 * np.random.randn(size_of_sample)
data_y1 = mu1 + sigma1 * np.random.randn(size_of_sample)
data_x2 = mu2 + sigma2 * np.random.randn(size_of_sample)
data_y2 = mu2 + sigma2 * np.random.randn(size_of_sample)

# プロットエリアの定義
fig = plt.figure(figsize=(6, 6))
ax = fig.add_subplot(1, 1, 1)

# タイトルを付ける
plt.title(title, fontsize=20)

# 散布図
plt.scatter(data_x1, data_y1, color='r', edgecolor='k', marker='o',
            s=24, label='data-1')
plt.scatter(data_x2, data_y2, color='b', edgecolor='k', marker='o',
            s=24, label='data-2')
#
# x軸、y軸の範囲
plt.xlim([xmin, xmax])
plt.ylim([ymin, ymax])
# x軸のラベル
plt.xlabel(xlabel, fontsize=16)
# y軸のラベル
plt.ylabel(ylabel, fontsize=16)
#
# x軸の目盛り
ax.xaxis.set_major_locator(ticker.AutoLocator())
ax.xaxis.set_minor_locator(ticker.AutoMinorLocator())
# y軸の目盛り
ax.yaxis.set_major_locator(ticker.AutoLocator())
ax.yaxis.set_minor_locator(ticker.AutoMinorLocator())
#
# 凡例を描く
plt.legend(loc='best')
# グリッド線を描く
plt.grid(color='gray', ls=':')
# プロット範囲の調整
plt.subplots_adjust(hspace=0.8, bottom=0.2)
#
# ファイルへの書き出し
fig_fname = "Fig4-5-8.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
#
plt.show()
