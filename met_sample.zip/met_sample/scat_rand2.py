#!/usr/bin/env python3
import matplotlib.pyplot as plt
import numpy as np
#print(plt.rcParams['lines.markersize'])

# サンプルサイズを設定
size_of_sample = 1000

# 作図範囲の設定
xmin = None
xmax = None
ymin = None
ymax = None

# タイトルの設定
title = "Scatter diagram"

# 再現性を保つため、random stateを固定
np.random.seed(1900)
# ランダムデータの準備
data_x = np.random.randn(size_of_sample)
data_y = np.random.randn(size_of_sample)

# プロットエリアの定義
#fig, ax1 = plt.subplots()
fig = plt.figure(figsize=(6, 6))
ax = fig.add_subplot(1, 1, 1)

# タイトルを付ける
plt.title(title)

# 散布図
plt.scatter(data_x, data_y, color='k', marker='o', s=6)
#plt.scatter(data_x, data_y, color='w', marker='o', s=6, edgecolor='k')
# s=(rcParams['lines.markersize'])**2, default: s = 36
#
# x軸、y軸の範囲
plt.xlim([xmin, xmax])
plt.ylim([ymin, ymax])
#
# グリッド線を描く
plt.grid(color='gray', ls=':')
# プロット範囲の調整
plt.subplots_adjust(hspace=0.8, bottom=0.2)
#
# ファイルへの書き出し
fig_fname = "Fig4-5-2.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
#
plt.show()
