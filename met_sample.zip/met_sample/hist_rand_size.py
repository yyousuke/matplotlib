#!/usr/bin/env python3
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import numpy as np
from pandas import Series
plt.rcParams['font.size'] = 8

# サンプルサイズを設定
size_of_sample = 100000

# ビンの端点の設定
edges = np.arange(-4.5, 4.5, 0.5)

# 作図範囲の設定
xmin = -4.5
xmax = 4.5
ymin = 0
ymax = 1.0

# 作図オプションのリスト
STYLES = [
    dict(alpha=1.0, fill=False, hatch='//'),
    dict(alpha=1.0, fill=False, hatch='//'),
    dict(alpha=1.0, fill=False, hatch='//'),
    dict(alpha=1.0, fill=False, hatch='//')
]

# プロットエリアの定義
#fig, ax1 = plt.subplots()
fig = plt.figure(figsize=(9, 2.5))

# タイトルを付ける
plt.axis('off')
plt.title("n = " + str(size_of_sample))

hist_y = list()
ax = list()
for n in np.arange(4):
    # ランダムデータの準備
    hist_y.append(np.random.randn(size_of_sample))
    # サブプロット作成
    ax.append(fig.add_subplot(1, 4, n + 1))
    # ヒストグラム
    ax[n].hist(hist_y[n], density=True, bins=edges, **STYLES[n])
    # グリッド線を描く
    ax[n].grid(color='gray', ls=':')
    # x軸の目盛り
    ax[n].xaxis.set_major_locator(ticker.AutoLocator())
    ax[n].xaxis.set_minor_locator(ticker.AutoMinorLocator())
    # x軸、y軸の範囲
    plt.xlim([xmin, xmax])
    plt.ylim([ymin, ymax])
    # 統計量の表示
    mean = ("mean = %3.2f" % Series(hist_y[n]).mean())
    std = ("SD = %3.2f" % Series(hist_y[n]).std())
    med = ("median = %3.2f" % Series(hist_y[n]).median())
    skew = ("skewness = %3.2f" % Series(hist_y[n]).skew())
    kurt = ("kurtosis = %3.2f" % Series(hist_y[n]).kurtosis())
    #
    plt.text(xmin + 0.5, ymax - 0.05, mean, fontsize=8)
    plt.text(xmin + 0.5, ymax - 0.1, std, fontsize=8)
    plt.text(xmin + 0.5, ymax - 0.15, med, fontsize=8)
    plt.text(xmin + 0.5, ymax - 0.2, skew, fontsize=8)
    plt.text(xmin + 0.5, ymax - 0.25, kurt, fontsize=8)

# プロット範囲の調整
plt.subplots_adjust(top=None, bottom=0.1, wspace=0.25, hspace=0.15)
#
# ファイルへの書き出し
fig_fname = "Fig4-4-5-" + str(size_of_sample) + ".png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
#
plt.show()
