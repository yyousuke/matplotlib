#!/usr/bin/env python3
import urllib.request
import netCDF4
import numpy as np

# データ取得の有無
retrieve = True
#retrieve = False

var_names = ["uwnd", "vwnd"]

for var_name in var_names:
    # URL
    url = "http://database.rish.kyoto-u.ac.jp/arch/ncep/data/ncep.reanalysis.derived/surface/" + var_name + ".mon.mean.nc"
    file_name = var_name + ".mon.mean.nc"
    #
    # ファイルのダウンロード
    if retrieve:
        urllib.request.urlretrieve(url, file_name)

    # NetCDFデータの読み込み
    nc = netCDF4.Dataset(file_name, 'r')

    # データサイズの取得
    idim = len(nc.dimensions['lon'])
    jdim = len(nc.dimensions['lat'])
    ndim = len(nc.dimensions['time'])
    datasize = idim * jdim  # size
    #print("lon = ", idim, ", lat = ", jdim, ", time = ", ndim)

    # 変数の読み込み
    lon = nc.variables["lon"][:]
    lat = nc.variables["lat"][:]
    time = nc.variables["time"][:]
    var = nc.variables[var_name][:]

    # ファイルを閉じる
    nc.close()

    # バイナリファイル書き出し
    outputfile = "output_" + var_name + ".bin"
    np.array(var).tofile(outputfile)
