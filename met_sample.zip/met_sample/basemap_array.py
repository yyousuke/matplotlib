#!/usr/bin/env python3
import numpy as np
import array
import sys
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap

# プロット領域の作成
fig = plt.figure()

# Basemap呼び出し
# 正距円筒図法（latlon相当）の準備（low resolutionの海岸線）
m = Basemap(projection='cyl', llcrnrlat=-90, urcrnrlat=90, llcrnrlon=0,
            urcrnrlon=360, resolution='l')

# 海岸線を描く
m.drawcoastlines(linewidth=0.2, color='k')

# 背景に色を付ける
#m.drawmapboundary(fill_color='aqua')

# 大陸に色を付ける
#m.fillcontinents(color='w', lake_color='b')

# 緯度線を引く
m.drawparallels(np.arange(-90, 90, 30), color="0.9", fontsize='small',
                labels=[True, False, False, False])

# 経度線を引く
m.drawmeridians(np.arange(0, 360, 30), color="0.9", fontsize='small',
                labels=[False, False, False, True])

# データサイズ
idim = 144
jdim = 73
datasize = idim * jdim
# 1948年7月
tstr = 7
tend = 7
num_rec = tend - tstr + 1
#
with open("output.bin", 'rb') as fin:
    # tstrの前まで読み飛ばす
    fin.seek(4 * datasize * (tstr - 1), 0)
    # データの読み込み
    buf = array.array('f')
    buf.fromfile(fin, datasize * num_rec)
#    if sys.byteorder == 'big':
#        buf.byteswap()
# bufからlistに変換
work = buf.tolist()
# listをx-, y-, z-の配列に
slp = np.array(work).reshape(num_rec, jdim, idim)
slp_jul = slp[0, :, :]
print("slp:", slp.shape)
print(slp_jul.min(), slp_jul.max())
#
# 緯度・経度座標の準備
nlats = jdim
nlons = idim
delta = 360. / (nlons - 1)
lats = (90. - delta * np.indices((nlats, nlons))[0, :, :])
lons = (delta * np.indices((nlats, nlons))[1, :, :])
# 図法の経度、緯度に変換する
x, y = m(lons, lats)
#
# 等値線を描く
clevs = np.arange(np.floor(slp_jul.min() - np.fmod(slp_jul.min(), 20)),
                  np.ceil(slp_jul.max()) + 1, 4)
cs = m.contour(x, y, slp_jul, clevs, linewidths=0.8, colors='k')

# ラベルを付ける
clevels = cs.levels
cs.clabel(clevels[::5], fontsize=12, fmt="%d")

# ファイルへの書き出し
fig_fname = "Fig6-5-15.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
