#!/usr/bin/env python3
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

# x, y軸サンプルデータ
n = 200
x = np.linspace(-10, 10, n)
y = np.linspace(-10, 10, n)

# x, y軸メッシュデータ
X, Y = np.meshgrid(x, y)
# z軸データ
Z = np.sqrt(X**2 + Y**2)
#
# プロットエリアの定義
fig = plt.figure(figsize=(5, 5))
ax = fig.add_subplot(1, 1, 1)

# 陰影を付ける
levels = np.arange(np.floor(Z.min()), np.ceil(Z.max()) + 1, 1.5)
plt.contourf(X, Y, Z, levels=levels, cmap='bwr')

# グリッド線を付ける
plt.grid(color='gray', ls='--')
# 縦横比を調整
plt.gca().set_aspect('equal')

# x軸の目盛り
ax.xaxis.set_major_locator(ticker.AutoLocator())
ax.xaxis.set_minor_locator(ticker.AutoLocator())
# y軸の目盛り
ax.yaxis.set_major_locator(ticker.AutoLocator())
ax.yaxis.set_minor_locator(ticker.AutoLocator())

# ファイルへの書き出し
fig_fname = "Fig5-3-2.png"
plt.savefig(fig_fname, dpi=300, bbox_inches='tight')
plt.show()
